import { Router } from "express";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { checkAllUpdates, clearUpdateCache } from "../services/updates.js";
import logger from "../logger.js";

const router = Router();
router.use(requireAuth, requireAdmin);

// Get update status for all containers
router.get("/", async (req, res) => {
  try {
    logger.info(`Update check requested by ${req.user.username}`);
    const results = await checkAllUpdates();
    res.json(results);
  } catch (err) {
    logger.error("Update check failed: " + err.message);
    res.status(500).json({ error: err.message });
  }
});

// Force re-check (clear cache)
router.post("/refresh", async (req, res) => {
  clearUpdateCache();
  try {
    const results = await checkAllUpdates();
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
