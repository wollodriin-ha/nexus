import { Router } from "express";
import { readFileSync, writeFileSync, readdirSync, unlinkSync, existsSync, mkdirSync, renameSync } from "node:fs";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import { requireAuth } from "../middleware/auth.js";
import logger from "../logger.js";

const router = Router();
router.use(requireAuth);

const WIKI_DIR = join(process.env.DATA_DIR || "./data", "wiki");
if (!existsSync(WIKI_DIR)) mkdirSync(WIKI_DIR, { recursive: true });

// Sanitize slug: only allow a-z 0-9 and dashes
function slugify(str) {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);
}

function getPagePath(slug) {
  const clean = slugify(slug);
  if (!clean) return null;
  return join(WIKI_DIR, `${clean}.json`);
}

// List all pages
router.get("/pages", (req, res) => {
  try {
    const files = readdirSync(WIKI_DIR).filter(f => f.endsWith(".json"));
    const pages = files.map(f => {
      try {
        const data = JSON.parse(readFileSync(join(WIKI_DIR, f), "utf-8"));
        return { slug: f.replace(".json", ""), title: data.title, icon: data.icon, updatedAt: data.updatedAt, createdAt: data.createdAt };
      } catch { return null; }
    }).filter(Boolean).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    res.json(pages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single page
router.get("/pages/:slug", (req, res) => {
  const fp = getPagePath(req.params.slug);
  if (!fp) return res.status(400).json({ error: "Slug invalide" });
  if (!existsSync(fp)) return res.status(404).json({ error: "Page introuvable" });
  try {
    const data = JSON.parse(readFileSync(fp, "utf-8"));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create or update page
router.put("/pages/:slug", (req, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: "Admin requis" });

  const slug = slugify(req.params.slug);
  if (!slug) return res.status(400).json({ error: "Slug invalide" });
  const fp = join(WIKI_DIR, `${slug}.json`);

  const { title, content, icon } = req.body;
  if (!title || content === undefined) return res.status(400).json({ error: "title et content requis" });

  const now = Date.now();
  let existing = null;
  if (existsSync(fp)) {
    try { existing = JSON.parse(readFileSync(fp, "utf-8")); } catch {}
  }

  const page = {
    slug,
    title: String(title).slice(0, 200),
    content: String(content).slice(0, 500000),
    icon: icon || "FileText",
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    updatedBy: req.user.username,
  };

  // Atomic write
  const tmp = `${fp}.${randomBytes(4).toString("hex")}.tmp`;
  writeFileSync(tmp, JSON.stringify(page, null, 2), "utf-8");
  renameSync(tmp, fp);

  logger.info(`Wiki ${existing ? "updated" : "created"}: ${slug} by ${req.user.username}`);
  res.json({ ok: true, page });
});

// Delete page
router.delete("/pages/:slug", (req, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: "Admin requis" });

  const fp = getPagePath(req.params.slug);
  if (!fp) return res.status(400).json({ error: "Slug invalide" });
  if (!existsSync(fp)) return res.status(404).json({ error: "Page introuvable" });

  try {
    unlinkSync(fp);
    logger.info(`Wiki deleted: ${req.params.slug} by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
