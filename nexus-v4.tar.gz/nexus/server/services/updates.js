import logger from "../logger.js";
import config from "../config.js";
import Dockerode from "dockerode";

/**
 * Update Tracker — checks if container images have newer versions available.
 *
 * How it works:
 *   1. Get the local image digest for each container
 *   2. Query the registry (Docker Hub, GHCR, lscr.io) for the latest digest
 *   3. Compare — if different, an update is available
 *
 * Supports:
 *   - Docker Hub (library/* and user/repo)
 *   - GitHub Container Registry (ghcr.io)
 *   - LinuxServer (lscr.io → ghcr.io)
 *
 * Results are cached for 1 hour to avoid hammering registries.
 */

const cache = new Map(); // key: image name → { checkedAt, localDigest, remoteDigest, updateAvailable }
const CACHE_TTL = 60 * 60 * 1000; // 1 hour

// ── Registry auth token (Docker Hub) ──
async function getDockerHubToken(repo) {
  try {
    const res = await fetch(`https://auth.docker.io/token?service=registry.docker.io&scope=repository:${repo}:pull`, {
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.token || null;
  } catch { return null; }
}

// ── Get remote digest from registry ──
async function getRemoteDigest(imageName) {
  let registry = "https://registry-1.docker.io";
  let repo = imageName;
  let tag = "latest";
  let authHeader = null;

  // Parse image:tag
  if (repo.includes(":")) {
    const parts = repo.split(":");
    tag = parts.pop();
    repo = parts.join(":");
  }

  // Detect registry
  if (repo.startsWith("ghcr.io/")) {
    registry = "https://ghcr.io";
    repo = repo.replace("ghcr.io/", "");
    // GHCR anonymous pull
    authHeader = null;
  } else if (repo.startsWith("lscr.io/")) {
    // lscr.io is a mirror of ghcr.io
    registry = "https://ghcr.io";
    repo = repo.replace("lscr.io/", "");
    authHeader = null;
  } else if (repo.startsWith("docker.io/")) {
    repo = repo.replace("docker.io/", "");
    if (!repo.includes("/")) repo = `library/${repo}`;
    const token = await getDockerHubToken(repo);
    if (token) authHeader = `Bearer ${token}`;
  } else if (!repo.includes("/") || (!repo.includes(".") && repo.split("/").length <= 2)) {
    // Docker Hub shorthand: "nginx" → "library/nginx", "user/repo" stays
    if (!repo.includes("/")) repo = `library/${repo}`;
    const token = await getDockerHubToken(repo);
    if (token) authHeader = `Bearer ${token}`;
  }

  // Fetch manifest to get digest
  try {
    const headers = {
      Accept: "application/vnd.docker.distribution.manifest.v2+json, application/vnd.oci.image.index.v1+json",
    };
    if (authHeader) headers.Authorization = authHeader;

    const res = await fetch(`${registry}/v2/${repo}/manifests/${tag}`, {
      headers,
      signal: AbortSignal.timeout(15_000),
    });

    if (!res.ok) {
      logger.debug(`Registry ${registry}/v2/${repo}/manifests/${tag}: ${res.status}`);
      return null;
    }

    // The digest is in the header
    const digest = res.headers.get("docker-content-digest");
    return digest || null;
  } catch (err) {
    logger.debug(`Registry check failed for ${repo}:${tag}: ${err.message}`);
    return null;
  }
}

// ── Get local image digest ──
async function getLocalDigest(docker, imageId) {
  try {
    const image = docker.getImage(imageId);
    const info = await image.inspect();
    // RepoDigests contains the digest from the registry when the image was pulled
    const digests = info.RepoDigests || [];
    if (digests.length > 0) {
      const d = digests[0];
      return d.includes("@") ? d.split("@")[1] : null;
    }
    return null;
  } catch { return null; }
}

// ── Check a single container ──
async function checkContainer(docker, container) {
  const image = container.image;
  const cacheKey = `${container.host}:${image}`;

  // Return cached result if fresh
  if (cache.has(cacheKey)) {
    const cached = cache.get(cacheKey);
    if (Date.now() - cached.checkedAt < CACHE_TTL) {
      return cached;
    }
  }

  const localDigest = await getLocalDigest(docker, container.imageId || image);
  const remoteDigest = await getRemoteDigest(image);

  const result = {
    image,
    checkedAt: Date.now(),
    localDigest: localDigest ? localDigest.slice(0, 19) : null,
    remoteDigest: remoteDigest ? remoteDigest.slice(0, 19) : null,
    updateAvailable: localDigest && remoteDigest ? localDigest !== remoteDigest : null,
    error: !remoteDigest ? "Impossible de vérifier" : null,
  };

  cache.set(cacheKey, result);
  return result;
}

// ── Check all containers across all hosts ──
export async function checkAllUpdates() {
  const hosts = config.getDockerHosts();
  const results = [];

  for (const host of hosts) {
    let docker;
    try {
      const opts = host.method === "socket"
        ? { socketPath: host.ip || "/var/run/docker.sock" }
        : { host: host.ip, port: host.port || 2375, protocol: "http" };
      docker = new Dockerode(opts);
    } catch (err) {
      logger.warn(`Update check: can't connect to ${host.name}: ${err.message}`);
      continue;
    }

    try {
      const containers = await docker.listContainers({ all: true });
      for (const c of containers) {
        const name = (c.Names[0] || "").replace(/^\//, "");
        const image = c.Image;

        try {
          const check = await checkContainer(docker, { image, imageId: c.ImageID, host: host.id });
          results.push({
            host: host.id,
            hostName: host.name,
            containerId: c.Id.slice(0, 12),
            name,
            image,
            state: c.State,
            ...check,
          });
        } catch (err) {
          results.push({
            host: host.id,
            hostName: host.name,
            containerId: c.Id.slice(0, 12),
            name,
            image,
            state: c.State,
            updateAvailable: null,
            error: err.message,
            checkedAt: Date.now(),
          });
        }
      }
    } catch (err) {
      logger.warn(`Update check on ${host.name}: ${err.message}`);
    }
  }

  return results;
}

// ── Clear cache (force re-check) ──
export function clearUpdateCache() {
  cache.clear();
}
