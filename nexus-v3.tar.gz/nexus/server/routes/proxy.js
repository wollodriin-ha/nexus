import { createProxyMiddleware } from "http-proxy-middleware";
import { verifyToken, hasServiceAccess } from "../middleware/auth.js";
import config from "../config.js";
import logger from "../logger.js";

/**
 * Server-side subpath proxy for Nexus.
 *
 * Each service lives under /s/<serviceId>/.
 * The service must have its UrlBase configured to match (e.g. /s/sonarr).
 *
 * For services without UrlBase support (Transmission), use rewriteTo
 * to map /s/transmission → /transmission.
 *
 * Auth is injected server-side:
 *   - apikey: X-Api-Key header + ?apikey= query param (for *arr web UIs)
 *   - basic: Authorization: Basic header
 *   - none: passthrough
 *
 * IMPORTANT for *arr apps: Set AuthenticationMethod=External in the
 * service's Settings > General. The API key is still needed for the
 * UI's internal API calls.
 */

const proxyCache = new Map();

function getOrCreateProxy(svc) {
  // Cache key includes everything that affects proxy behavior
  const key = JSON.stringify({ id: svc.id, url: svc.url, authType: svc.authType, rewriteTo: svc.rewriteTo, basePath: svc.basePath });
  if (proxyCache.has(key)) return proxyCache.get(key);

  let targetUrl;
  try { targetUrl = new URL(svc.url); }
  catch { throw new Error(`URL invalide pour ${svc.label}: ${svc.url}`); }

  const hasRewrite = svc.rewriteTo !== null && svc.rewriteTo !== undefined;

  const proxyOpts = {
    target: svc.url,
    changeOrigin: true,
    ws: true,
    secure: false,

    // Rewrite redirects: replace internal host with the Nexus host
    autoRewrite: true,

    // Path rewriting only for services without UrlBase support
    pathRewrite: hasRewrite ? (path) => {
      const prefix = `/s/${svc.id}`;
      const rest = path.startsWith(prefix) ? path.slice(prefix.length) : path;
      return (svc.rewriteTo || "") + rest;
    } : undefined,

    on: {
      proxyReq: (proxyReq, req) => {
        // ── Inject authentication ──
        if (svc.authType === "apikey" && svc.apiKey) {
          // Header for API calls
          proxyReq.setHeader("X-Api-Key", svc.apiKey);
          // Query param for page loads — *arr apps check this
          const currentPath = proxyReq.path || "/";
          if (!currentPath.includes("apikey=")) {
            const sep = currentPath.includes("?") ? "&" : "?";
            proxyReq.path = currentPath + sep + "apikey=" + encodeURIComponent(svc.apiKey);
          }
        } else if (svc.authType === "basic" && svc.username) {
          const cred = Buffer.from(`${svc.username}:${svc.password || ""}`).toString("base64");
          proxyReq.setHeader("Authorization", `Basic ${cred}`);
        }

        // Forward service cookies but strip nexus_token (don't leak our auth)
        const rawCookies = req.headers.cookie || "";
        const filtered = rawCookies.split(";").map(c => c.trim()).filter(c => !c.startsWith("nexus_token=")).join("; ");
        if (filtered) { proxyReq.setHeader("cookie", filtered); }
        else { proxyReq.removeHeader("cookie"); }
      },

      proxyRes: (proxyRes, req) => {
        // ── Allow iframe embedding ──
        delete proxyRes.headers["x-frame-options"];
        delete proxyRes.headers["content-security-policy"];
        delete proxyRes.headers["content-security-policy-report-only"];

        // ── Scope service cookies to /s/<id>/ path so they don't overwrite nexus_token ──
        if (proxyRes.headers["set-cookie"]) {
          const scoped = (Array.isArray(proxyRes.headers["set-cookie"])
            ? proxyRes.headers["set-cookie"]
            : [proxyRes.headers["set-cookie"]]
          ).map(cookie => {
            // Remove existing Path= and add scoped path
            const cleaned = cookie.replace(/;\s*[Pp]ath=[^;]*/g, "");
            return `${cleaned}; Path=/s/${svc.id}/`;
          });
          proxyRes.headers["set-cookie"] = scoped;
        }

        // ── Fix redirects that still point to the internal IP ──
        // autoRewrite handles most, but catch any remaining ones
        const loc = proxyRes.headers.location;
        if (loc) {
          const internalHost = targetUrl.host; // e.g. "10.0.0.2:8989"
          if (loc.includes(internalHost)) {
            const proto = req.headers["x-forwarded-proto"] || (req.secure ? "https" : "http");
            const host = req.headers["x-forwarded-host"] || req.headers.host;
            const fixed = loc.replace(new RegExp(`https?://${internalHost.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, "g"), `${proto}://${host}`);
            proxyRes.headers.location = fixed;
          }
        }
      },

      error: (err, req, res) => {
        logger.error(`Proxy ${svc.id} → ${svc.url}: ${err.message}`);
        if (res && !res.headersSent) {
          res.status(502).send(
            `<!DOCTYPE html><html><body style="background:#0a0e17;color:#dfe6f2;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">` +
            `<div style="text-align:center"><h2 style="color:#ef4444">${svc.label} indisponible</h2>` +
            `<p style="color:#8896b3">Impossible de joindre <code>${svc.url}</code></p>` +
            `<p style="color:#4a5578;font-size:13px">${err.message}</p></div></body></html>`
          );
        }
      },
    },

    timeout: 30_000,
    proxyTimeout: 30_000,
  };

  const proxy = createProxyMiddleware(proxyOpts);
  proxyCache.set(key, proxy);
  logger.info(`Proxy ready: /s/${svc.id} → ${svc.url} [auth=${svc.authType}${hasRewrite ? ", rewrite→" + svc.rewriteTo : ""}]`);
  return proxy;
}

/**
 * Express middleware mounted at app level.
 * Intercepts all /s/<serviceId>/* requests.
 */
export function createServiceProxy() {
  return (req, res, next) => {
    // Match /s/sonarr or /s/sonarr/anything
    const match = req.path.match(/^\/s\/([a-z0-9-]+)(\/.*)?$/);
    if (!match) return next();

    const serviceId = match[1];
    const svc = config.getServiceById(serviceId);

    // Validate service
    if (!svc || !svc.enabled) return res.status(404).send("Service introuvable ou desactive");
    if (!svc.url) return res.status(400).send(`${svc.label}: URL non configuree dans Parametres`);

    // Validate auth cookie
    const token = req.cookies?.nexus_token;
    if (!token) return res.redirect("/?login=1");

    let user;
    try { user = verifyToken(token); }
    catch { return res.redirect("/?login=1"); }

    // Check permission
    if (!hasServiceAccess(user, serviceId)) return res.status(403).send("Acces refuse");

    // Proxy
    try {
      const proxy = getOrCreateProxy(svc);
      proxy(req, res, next);
    } catch (err) {
      logger.error(`Proxy init ${svc.id}: ${err.message}`);
      res.status(500).send(`Erreur proxy: ${err.message}`);
    }
  };
}

export function clearProxyCache() {
  proxyCache.clear();
  logger.info("Proxy cache cleared");
}
