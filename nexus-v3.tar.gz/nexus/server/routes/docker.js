import { Router } from "express";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import * as docker from "../services/docker.js";
import logger from "../logger.js";

const router = Router();
router.use(requireAuth, requireAdmin);

router.get("/containers", async (req, res) => {
  try { const { host } = req.query; res.json(host ? await docker.listContainers(host) : await docker.listAllContainers()); }
  catch (err) { logger.error("Docker: " + err.message); res.status(500).json({ error: err.message }); }
});

router.post("/containers/:hostId/:containerId/:action", async (req, res) => {
  const { hostId, containerId, action } = req.params;
  if (!["start","stop","restart","logs","pull"].includes(action)) return res.status(400).json({ error: "Action invalide" });
  try { logger.info(`Docker ${action}: ${containerId} on ${hostId} by ${req.user.username}`); res.json(await docker.containerAction(hostId, containerId, action)); }
  catch (err) { logger.error(`Docker ${action}: ${err.message}`); res.status(500).json({ error: err.message }); }
});

router.get("/hosts/info", async (req, res) => {
  try { res.json(await docker.getAllHostInfo()); } catch (err) { res.status(500).json({ error: err.message }); }
});

export default router;
