import { Router } from "express";
import { authenticateUser } from "../services/jellyfin.js";
import { signToken, requireAuth, cookieOptions } from "../middleware/auth.js";
import logger from "../logger.js";

const router = Router();

router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: "Champs requis" });
  try {
    const u = await authenticateUser(username, password);
    const token = signToken({ userId: u.userId, username: u.username, isAdmin: u.isAdmin });
    res.cookie("nexus_token", token, cookieOptions(req));
    logger.info(`Login: ${u.username} (admin=${u.isAdmin})`);
    res.json({ user: { userId: u.userId, username: u.username, isAdmin: u.isAdmin } });
  } catch (err) {
    logger.warn(`Login failed "${username}": ${err.message}`);
    res.status(401).json({ error: "Identifiants invalides" });
  }
});

router.post("/logout", (req, res) => { res.clearCookie("nexus_token", { path: "/" }); res.json({ ok: true }); });
router.get("/me", requireAuth, (req, res) => { res.json({ user: req.user }); });

export default router;
