import jwt from "jsonwebtoken";
import config from "../config.js";

const SECRET = () => process.env.JWT_SECRET || "INSECURE_DEFAULT";

export function signToken(payload) {
  return jwt.sign(payload, SECRET(), { expiresIn: process.env.JWT_EXPIRY || "7d" });
}

export function verifyToken(token) {
  return jwt.verify(token, SECRET());
}

export function cookieOptions(req) {
  const isHttps = req.secure || req.headers["x-forwarded-proto"] === "https";
  return {
    httpOnly: true,
    secure: isHttps,
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  };
}

export function requireAuth(req, res, next) {
  const token = req.cookies?.nexus_token || req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Non authentifie" });
  try { req.user = verifyToken(token); next(); }
  catch { res.clearCookie("nexus_token", { path: "/" }); return res.status(401).json({ error: "Session expiree" }); }
}

export function requireAdmin(req, res, next) {
  if (!req.user?.isAdmin) return res.status(403).json({ error: "Admin requis" });
  next();
}

export function hasServiceAccess(user, serviceId) {
  if (user?.isAdmin) return true;
  const perms = config.getUserPerms(user?.userId);
  return perms && perms[serviceId] === true;
}
