import express from "express";
import helmet from "helmet";
import cors from "cors";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

import logger from "./logger.js";
import authRoutes from "./routes/auth.js";
import dockerRoutes from "./routes/docker.js";
import settingsRoutes from "./routes/settings.js";
import { createServiceProxy } from "./routes/proxy.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = parseInt(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === "production";

if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false, crossOriginOpenerPolicy: false, crossOriginResourcePolicy: false }));
app.use(cors({ origin: isProd ? false : ["http://localhost:5173"], credentials: true }));
app.use("/api/", rateLimit({ windowMs: 15 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));
app.use("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, max: 15 }));

app.use(cookieParser());
// Don't compress proxy responses (services handle their own)
app.use((req, res, next) => { if (req.path.startsWith("/s/")) return next(); compression()(req, res, next); });
app.use(express.json({ limit: "1mb" }));
app.use(morgan("short", { stream: { write: m => logger.http(m.trim()) } }));

// Service proxy FIRST — before API and static
app.use(createServiceProxy());

// API
app.use("/api/auth", authRoutes);
app.use("/api/docker", dockerRoutes);
app.use("/api/settings", settingsRoutes);
app.get("/api/health", (req, res) => res.json({ ok: true, uptime: process.uptime() }));

// Static frontend
const dist = join(__dirname, "..", "client", "dist");
if (isProd && existsSync(dist)) {
  app.use(express.static(dist, { maxAge: "1d" }));
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/") || req.path.startsWith("/s/")) return res.status(404).json({ error: "Not found" });
    res.sendFile(join(dist, "index.html"));
  });
}

app.use((err, req, res, _next) => { logger.error(err); res.status(500).json({ error: isProd ? "Erreur interne" : err.message }); });

app.listen(PORT, () => {
  logger.info(`Nexus v3 on :${PORT} (${isProd ? "prod" : "dev"})`);
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET === "CHANGE_ME") logger.warn("JWT_SECRET not set!");
  if (!process.env.JELLYFIN_URL) logger.warn("JELLYFIN_URL not set!");
});
