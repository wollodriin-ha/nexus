import Dockerode from "dockerode";
import logger from "../logger.js";
import config from "../config.js";

const pool = new Map();

function getClient(host) {
  if (pool.has(host.id)) return pool.get(host.id);
  const opts = host.method === "socket"
    ? { socketPath: host.ip || "/var/run/docker.sock" }
    : { host: host.ip, port: host.port || 2375, protocol: host.method === "tls" ? "https" : "http" };
  const c = new Dockerode(opts);
  pool.set(host.id, c);
  return c;
}

function resolveHost(id) {
  const h = config.getDockerHosts().find(x => x.id === id);
  if (!h) throw new Error("Hote introuvable: " + id);
  return h;
}

export async function listContainers(hostId) {
  const host = resolveHost(hostId);
  const raw = await getClient(host).listContainers({ all: true });
  return raw.map(c => ({
    id: c.Id.slice(0, 12), name: (c.Names[0] || "").replace(/^\//, ""),
    image: c.Image, state: c.State, status: c.Status, host: hostId,
    ports: (c.Ports || []).map(p => p.PublicPort ? `${p.PublicPort}:${p.PrivatePort}` : String(p.PrivatePort)).join(", "),
  }));
}

export async function listAllContainers() {
  const results = [];
  for (const host of config.getDockerHosts()) {
    try { results.push(...await listContainers(host.id)); }
    catch (err) { logger.warn(`Docker ${host.name}: ${err.message}`); }
  }
  return results;
}

export async function containerAction(hostId, containerId, action) {
  const host = resolveHost(hostId);
  const container = getClient(host).getContainer(containerId);
  switch (action) {
    case "start": await container.start(); return { ok: true };
    case "stop": await container.stop({ t: 10 }); return { ok: true };
    case "restart": await container.restart({ t: 10 }); return { ok: true };
    case "logs": {
      const buf = await container.logs({ stdout: true, stderr: true, tail: 300, timestamps: true });
      return { ok: true, logs: buf.toString("utf-8") };
    }
    case "pull": {
      const docker = getClient(host);
      const info = await container.inspect();
      const image = info.Config.Image;
      await new Promise((res, rej) => { docker.pull(image, (e, s) => { if (e) return rej(e); docker.modem.followProgress(s, e => e ? rej(e) : res()); }); });
      const wasRunning = info.State.Running;
      if (wasRunning) await container.stop({ t: 10 });
      const name = info.Name.replace(/^\//, "");
      await container.remove();
      const nc = await docker.createContainer({ ...info.Config, name, HostConfig: info.HostConfig, NetworkingConfig: { EndpointsConfig: info.NetworkSettings?.Networks || {} } });
      if (wasRunning) await nc.start();
      return { ok: true, message: `Pull & recreate: ${image}` };
    }
    default: throw new Error("Action inconnue");
  }
}

export async function getAllHostInfo() {
  const results = [];
  for (const host of config.getDockerHosts()) {
    try {
      const info = await getClient(host).info();
      results.push({ id: host.id, name: host.name, os: info.OperatingSystem, containers: info.Containers, running: info.ContainersRunning, cpus: info.NCPU, memGB: Math.round((info.MemTotal || 0) / 1073741824 * 10) / 10 });
    } catch (err) { results.push({ id: host.id, name: host.name, error: err.message }); }
  }
  return results;
}
