import { readFileSync, writeFileSync, renameSync, existsSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { randomBytes } from "node:crypto";

const DATA_DIR = process.env.DATA_DIR || "./data";
if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

const DEFAULTS = {
  services: [
    { id: "jellyfin", label: "Jellyfin", icon: "MonitorPlay", color: "#a78bfa", port: 8096, url: "", basePath: "/s/jellyfin", rewriteTo: null, authType: "apikey", apiKey: "", username: "", password: "", isSSO: true, enabled: true, removable: false },
    { id: "sonarr", label: "Sonarr", icon: "Tv", color: "#3b82f6", port: 8989, url: "", basePath: "/s/sonarr", rewriteTo: null, authType: "apikey", apiKey: "", username: "", password: "", enabled: true, removable: false },
    { id: "radarr", label: "Radarr", icon: "Film", color: "#f59e0b", port: 7878, url: "", basePath: "/s/radarr", rewriteTo: null, authType: "apikey", apiKey: "", username: "", password: "", enabled: true, removable: false },
    { id: "prowlarr", label: "Prowlarr", icon: "Search", color: "#ec4899", port: 9696, url: "", basePath: "/s/prowlarr", rewriteTo: null, authType: "apikey", apiKey: "", username: "", password: "", enabled: true, removable: false },
    { id: "jellyseerr", label: "Jellyseerr", icon: "Inbox", color: "#14b8a6", port: 5055, url: "", basePath: "/s/jellyseerr", rewriteTo: null, authType: "none", apiKey: "", username: "", password: "", enabled: true, removable: false },
    { id: "transmission", label: "Transmission", icon: "Download", color: "#22d3ee", port: 9091, url: "", basePath: "/s/transmission", rewriteTo: "/transmission", authType: "basic", apiKey: "", username: "", password: "", enabled: true, removable: false },
  ],
  dockerHosts: [],
  userPermissions: {},
};

function readJSON(file) {
  const fp = join(DATA_DIR, file);
  if (!existsSync(fp)) return null;
  try { return JSON.parse(readFileSync(fp, "utf-8")); } catch { return null; }
}

function writeJSON(file, data) {
  const fp = join(DATA_DIR, file);
  const tmp = `${fp}.${randomBytes(4).toString("hex")}.tmp`;
  writeFileSync(tmp, JSON.stringify(data, null, 2), "utf-8");
  renameSync(tmp, fp);
}

class Config {
  #d = null;

  load() {
    if (this.#d) return this.#d;
    const s = readJSON("config.json");
    if (s) {
      const merged = { ...DEFAULTS, ...s };
      merged.services = (s.services || DEFAULTS.services).map(svc => {
        const def = DEFAULTS.services.find(d => d.id === svc.id) || {};
        return { ...def, ...svc };
      });
      this.#d = merged;
    } else {
      this.#d = structuredClone(DEFAULTS);
    }
    return this.#d;
  }

  #save() { writeJSON("config.json", this.#d); return this.#d; }
  reload() { this.#d = null; return this.load(); }

  getServices() { return this.load().services; }
  getServiceById(id) { return this.getServices().find(s => s.id === id) || null; }

  addService(svc) {
    const c = this.load();
    if (c.services.some(s => s.id === svc.id)) throw new Error("ID existe deja");
    c.services.push({ ...svc, removable: true, enabled: true });
    return this.#save();
  }

  removeService(id) {
    const c = this.load();
    const s = c.services.find(x => x.id === id);
    if (!s) throw new Error("Introuvable");
    if (!s.removable) throw new Error("Non supprimable");
    c.services = c.services.filter(x => x.id !== id);
    return this.#save();
  }

  updateService(id, u) {
    const c = this.load();
    const i = c.services.findIndex(s => s.id === id);
    if (i === -1) throw new Error("Introuvable");
    const OK = ["label","icon","color","port","url","basePath","rewriteTo","authType","apiKey","username","password","enabled"];
    for (const k of OK) { if (u[k] !== undefined) c.services[i][k] = u[k]; }
    return this.#save();
  }

  getDockerHosts() { return this.load().dockerHosts; }
  addDockerHost(h) { const c = this.load(); if (c.dockerHosts.some(x => x.id === h.id)) throw new Error("ID existe deja"); c.dockerHosts.push(h); return this.#save(); }
  removeDockerHost(id) { this.load().dockerHosts = this.load().dockerHosts.filter(h => h.id !== id); return this.#save(); }
  updateDockerHost(id, u) { const c = this.load(); const i = c.dockerHosts.findIndex(h => h.id === id); if (i === -1) throw new Error("Introuvable"); for (const k of ["name","ip","port","method","composePath","os"]) { if (u[k] !== undefined) c.dockerHosts[i][k] = u[k]; } return this.#save(); }

  getPermissions() { return this.load().userPermissions; }
  getUserPerms(uid) { return this.load().userPermissions[uid] || null; }
  setAllPermissions(m) { this.load().userPermissions = m; return this.#save(); }
}

export default new Config();
