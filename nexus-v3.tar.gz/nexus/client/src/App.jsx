import { useState, useReducer, useCallback, useMemo, useEffect, useRef } from "react";
import {
  Play, Square, RotateCcw, MonitorPlay, Tv, Film, Search, Download, Server,
  HardDrive, Settings, Home, ExternalLink, Maximize2, Minimize2, RefreshCw,
  Circle, Container, Layers, ArrowDownToLine, Menu, X, Globe, Terminal,
  Eye, EyeOff, Plus, Trash2, Check, Shield, LogOut, ArrowUpFromLine,
  PackageCheck, Inbox, Loader2, BarChart3, Zap, Gauge, Lock, Cpu,
  AlertTriangle
} from "lucide-react";
import { api } from "./lib/api.js";

const FM = "'IBM Plex Mono','Fira Code',monospace";
const FS = "'Outfit','DM Sans',sans-serif";
const C = {bg:"#060a11",bg2:"#0b1120",card:"#0f1629",cardHi:"#141d33",side:"#080d19",bdr:"#1a2340",bdrHi:"#253562",tx:"#dfe6f2",txS:"#8896b3",txD:"#4a5578",acc:"#00e5a0",blue:"#3b82f6",purple:"#8b5cf6",amber:"#f59e0b",red:"#ef4444",pink:"#ec4899",cyan:"#22d3ee",teal:"#14b8a6",ok:"#00e5a0",err:"#ef4444",warn:"#f59e0b"};
const ICONS = {MonitorPlay,Tv,Film,Search,Download,Server,Inbox,Globe,HardDrive,BarChart3,Shield,Zap,Gauge,Container,Layers,Lock,Cpu,Home,Settings};
const ICON_NAMES = Object.keys(ICONS);
const COLORS = ["#a78bfa","#3b82f6","#f59e0b","#ec4899","#22d3ee","#00e5a0","#ef4444","#14b8a6","#8b5cf6","#f97316"];

/* ── Reducer ── */
let _tid = 0;
const INIT = {user:null,page:"home",sidebar:true,fs:false,services:[],hosts:[],containers:[],users:[],stats:{media:{movies:0,series:0,episodes:0},streams:0},hostsInfo:[],toasts:[],modal:null,loading:true};

function reducer(s, a) {
  switch (a.type) {
    case "SET": return {...s, ...a.p};
    case "LOGIN": return {...s, user:a.p, loading:false};
    case "LOGOUT": return {...INIT, loading:false};
    case "NAV": return {...s, page:a.p, fs:false};
    case "SIDEBAR": return {...s, sidebar:!s.sidebar};
    case "FS": return {...s, fs:!s.fs};
    case "TOAST": return {...s, toasts:[...s.toasts.slice(-4), {id:++_tid, ...a.p}]};
    case "UTOAST": return {...s, toasts:s.toasts.filter(x => x.id !== a.p)};
    case "MODAL": return {...s, modal:a.p};
    default: return s;
  }
}

function useToast(d) {
  return useCallback((msg, v = "info") => {
    const id = ++_tid;
    d({type:"TOAST", p:{msg, v}});
    setTimeout(() => d({type:"UTOAST", p:id}), 3000);
  }, [d]);
}

/* ── Atoms ── */
function Pulse({color = C.ok, size = 7}) {
  return (
    <span style={{position:"relative",display:"inline-flex",width:size,height:size,flexShrink:0}}>
      <span style={{position:"absolute",inset:-2,borderRadius:"50%",backgroundColor:color,opacity:.3,animation:"nxP 2s ease-in-out infinite"}}/>
      <span style={{width:size,height:size,borderRadius:"50%",backgroundColor:color}}/>
    </span>
  );
}

function Badge({children, color = C.txD}) {
  return <span style={{fontFamily:FM,fontSize:10,color,background:`${color}14`,border:`1px solid ${color}22`,borderRadius:4,padding:"2px 7px",whiteSpace:"nowrap"}}>{children}</span>;
}

function Bar({value, color = C.acc, h = 4}) {
  return (
    <div style={{height:h,borderRadius:h/2,background:C.bdr,overflow:"hidden"}}>
      <div style={{height:"100%",borderRadius:h/2,width:`${Math.max(0,Math.min(100,value))}%`,background:`linear-gradient(90deg,${color},${color}90)`,transition:"width .6s ease"}}/>
    </div>
  );
}

function Card({children, style:sx, hover}) {
  const [h, setH] = useState(false);
  return (
    <div onMouseEnter={hover ? () => setH(true) : undefined} onMouseLeave={hover ? () => setH(false) : undefined}
      style={{background:C.card,border:`1px solid ${h?C.bdrHi:C.bdr}`,borderRadius:10,overflow:"hidden",transition:"border-color .2s,transform .15s",transform:h?"translateY(-1px)":"none",...sx}}>
      {children}
    </div>
  );
}

function Btn({children, onClick, variant, small, icon:Ic, disabled, style:sx}) {
  const [h, setH] = useState(false);
  const a = variant === "accent", d = variant === "danger";
  return (
    <button onClick={onClick} disabled={disabled} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{fontFamily:FS,fontSize:small?11:12,fontWeight:500,border:`1px solid ${a?C.acc+"50":d?C.red+"40":C.bdr}`,borderRadius:7,padding:small?"5px 10px":"8px 16px",cursor:disabled?"not-allowed":"pointer",display:"inline-flex",alignItems:"center",gap:6,background:h&&!disabled?(a?C.acc+"18":d?C.red+"12":C.cardHi):(a?C.acc+"08":"transparent"),color:a?C.acc:d?C.red:C.txS,opacity:disabled?.4:1,transition:"all .15s",...sx}}>
      {Ic && <Ic size={small?12:13}/>}{children}
    </button>
  );
}

function IconBtn({icon:Ic, color = C.txS, title, onClick, sz = 28}) {
  const [h, setH] = useState(false);
  return (
    <button title={title} onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{width:sz,height:sz,borderRadius:6,border:`1px solid ${h?color+"40":C.bdr}`,background:h?`${color}12`:"transparent",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all .15s",flexShrink:0}}>
      <Ic size={sz > 26 ? 13 : 11} color={color}/>
    </button>
  );
}

function TabBar({tabs, active, onChange}) {
  return (
    <div style={{display:"flex",gap:2,background:C.bg2,borderRadius:8,padding:3,border:`1px solid ${C.bdr}`,flexWrap:"wrap"}}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => onChange(t.id)}
          style={{fontFamily:FS,fontSize:12,fontWeight:active===t.id?600:400,color:active===t.id?C.tx:C.txD,background:active===t.id?C.card:"transparent",border:"none",borderRadius:6,padding:"6px 14px",cursor:"pointer",transition:"all .15s",whiteSpace:"nowrap"}}>
          {t.label}
        </button>
      ))}
    </div>
  );
}

function Toggle({on, onChange, disabled}) {
  return (
    <button onClick={disabled ? undefined : onChange}
      style={{width:34,height:19,borderRadius:10,border:"none",background:on?C.acc+"35":C.bdr,position:"relative",cursor:disabled?"not-allowed":"pointer",transition:"background .2s",opacity:disabled?.5:1,display:"inline-block",verticalAlign:"middle"}}>
      <span style={{position:"absolute",top:2,width:15,height:15,borderRadius:"50%",background:on?C.acc:C.txD,transition:"left .2s",left:on?17:2}}/>
    </button>
  );
}

function Field({label, value, onChange, type = "text", placeholder, mono}) {
  const [show, setShow] = useState(false);
  const pw = type === "password";
  return (
    <div>
      {label && <label style={{fontFamily:FS,fontSize:11,color:C.txD,display:"block",marginBottom:4}}>{label}</label>}
      <div style={{position:"relative"}}>
        <input value={value || ""} onChange={e => onChange?.(e.target.value)}
          type={pw && !show ? "password" : "text"} placeholder={placeholder}
          style={{width:"100%",fontFamily:mono?FM:FS,fontSize:12,color:C.tx,background:C.bg2,border:`1px solid ${C.bdr}`,borderRadius:6,padding:pw?"8px 36px 8px 12px":"8px 12px",outline:"none",transition:"border-color .2s"}}
          onFocus={e => {e.target.style.borderColor = C.acc + "50"}}
          onBlur={e => {e.target.style.borderColor = C.bdr}}/>
        {pw && (
          <button onClick={() => setShow(!show)} style={{position:"absolute",right:8,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",padding:2,display:"flex"}}>
            {show ? <EyeOff size={14} color={C.txD}/> : <Eye size={14} color={C.txD}/>}
          </button>
        )}
      </div>
    </div>
  );
}

function Sel({label, value, onChange, options}) {
  return (
    <div>
      {label && <label style={{fontFamily:FS,fontSize:11,color:C.txD,display:"block",marginBottom:4}}>{label}</label>}
      <select value={value || ""} onChange={e => onChange(e.target.value)}
        style={{width:"100%",fontFamily:FS,fontSize:12,color:C.tx,background:C.bg2,border:`1px solid ${C.bdr}`,borderRadius:6,padding:"8px 12px",outline:"none",cursor:"pointer"}}>
        {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
      </select>
    </div>
  );
}

function Modal({open, onClose, title, children}) {
  if (!open) return null;
  return (
    <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,backdropFilter:"blur(4px)"}}>
      <div onClick={e => e.stopPropagation()} style={{width:450,maxWidth:"92vw",maxHeight:"85vh",overflow:"auto",background:C.card,border:`1px solid ${C.bdr}`,borderRadius:14,animation:"nxUp .25s ease"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 20px",borderBottom:`1px solid ${C.bdr}`}}>
          <h3 style={{fontFamily:FS,fontSize:16,fontWeight:600,color:C.tx,margin:0}}>{title}</h3>
          <IconBtn icon={X} onClick={onClose} color={C.txD}/>
        </div>
        <div style={{padding:20}}>{children}</div>
      </div>
    </div>
  );
}

/* ── Login ── */
function LoginScreen({dispatch}) {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const submit = useCallback(async () => {
    if (!user.trim() || !pass.trim()) { setErr("Tous les champs sont requis"); return; }
    setLoading(true); setErr("");
    try {
      const data = await api.login(user.trim(), pass);
      dispatch({type:"LOGIN", p:data.user});
    } catch (e) { setErr(e.message || "Identifiants invalides"); }
    finally { setLoading(false); }
  }, [user, pass, dispatch]);

  const inp = {width:"100%",fontFamily:FS,fontSize:14,color:C.tx,background:C.bg2,border:`1px solid ${C.bdr}`,borderRadius:8,padding:"11px 14px",outline:"none"};

  return (
    <div style={{width:"100%",height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:C.bg,position:"relative"}}>
      <div style={{position:"absolute",inset:0,background:`radial-gradient(ellipse at 25% 15%,${C.acc}06 0%,transparent 50%),radial-gradient(ellipse at 75% 85%,${C.blue}05 0%,transparent 50%)`}}/>
      <div style={{position:"relative",width:380,animation:"nxUp .5s ease"}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{width:52,height:52,borderRadius:14,background:`linear-gradient(135deg,${C.acc},${C.cyan})`,display:"inline-flex",alignItems:"center",justifyContent:"center",marginBottom:14,boxShadow:`0 0 40px ${C.acc}20`}}>
            <Layers size={26} color={C.bg} strokeWidth={2.5}/>
          </div>
          <h1 style={{fontFamily:FS,fontSize:28,fontWeight:700,color:C.tx,margin:"0 0 4px",letterSpacing:"-.03em"}}>Nexus</h1>
          <p style={{fontFamily:FS,fontSize:13,color:C.txD}}>Connectez-vous avec votre compte Jellyfin</p>
        </div>
        <Card style={{padding:26}}>
          <div style={{marginBottom:16}}>
            <label style={{fontFamily:FS,fontSize:12,color:C.txS,display:"block",marginBottom:6}}>Utilisateur</label>
            <input value={user} onChange={e => setUser(e.target.value)} placeholder="Jellyfin username" style={inp} onKeyDown={e => e.key === "Enter" && submit()}/>
          </div>
          <div style={{marginBottom:18}}>
            <label style={{fontFamily:FS,fontSize:12,color:C.txS,display:"block",marginBottom:6}}>Mot de passe</label>
            <div style={{position:"relative"}}>
              <input value={pass} onChange={e => setPass(e.target.value)} type={show?"text":"password"} placeholder="••••••••" style={{...inp,paddingRight:40}} onKeyDown={e => e.key === "Enter" && submit()}/>
              <button onClick={() => setShow(!show)} style={{position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",padding:3,display:"flex"}}>
                {show ? <EyeOff size={15} color={C.txD}/> : <Eye size={15} color={C.txD}/>}
              </button>
            </div>
          </div>
          {err && <p style={{fontFamily:FS,fontSize:12,color:C.red,margin:"0 0 10px"}}>{err}</p>}
          <button onClick={submit} disabled={loading}
            style={{width:"100%",fontFamily:FS,fontSize:14,fontWeight:600,color:C.bg,background:loading?C.txD:`linear-gradient(135deg,${C.acc},${C.cyan})`,border:"none",borderRadius:8,padding:"12px",cursor:loading?"wait":"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
            {loading && <Loader2 size={16} style={{animation:"nxSpin .8s linear infinite"}}/>}
            {loading ? "Connexion..." : "Se connecter"}
          </button>
        </Card>
      </div>
    </div>
  );
}

/* ── Dashboard ── */
function DashHome({state}) {
  const svcs = useMemo(() => state.services.filter(s => s.enabled), [state.services]);
  const {media, streams} = state.stats;
  return (
    <div style={{flex:1,overflow:"auto",padding:28}}>
      <h2 style={{fontFamily:FS,fontSize:24,fontWeight:700,color:C.tx,margin:"0 0 3px",letterSpacing:"-.03em"}}>Dashboard</h2>
      <p style={{fontFamily:FS,fontSize:13,color:C.txD,margin:"0 0 22px"}}>Vue d'ensemble</p>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(175px,1fr))",gap:12,marginBottom:24}}>
        {[
          {l:"Films",v:media.movies,ic:Film,c:C.amber,s:"Radarr"},
          {l:"Séries",v:media.series,ic:Tv,c:C.blue,s:`${media.episodes} épisodes`},
          {l:"Streams",v:streams,ic:MonitorPlay,c:C.purple,s:"Jellyfin"},
        ].map(x => (
          <Card key={x.l} hover style={{padding:"16px 18px"}}>
            <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:10}}>
              <x.ic size={14} color={x.c}/>
              <span style={{fontFamily:FS,fontSize:10,color:C.txD,textTransform:"uppercase",letterSpacing:".06em"}}>{x.l}</span>
            </div>
            <div style={{fontFamily:FM,fontSize:26,fontWeight:700,color:C.tx,lineHeight:1}}>{x.v}</div>
            <div style={{fontFamily:FS,fontSize:11,color:C.txD,marginTop:5}}>{x.s}</div>
          </Card>
        ))}
      </div>

      <h3 style={{fontFamily:FS,fontSize:15,fontWeight:600,color:C.tx,margin:"0 0 14px"}}>Serveurs</h3>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(330px,1fr))",gap:14,marginBottom:24}}>
        {state.hostsInfo.map(h => (
          <Card key={h.id} hover style={{padding:"18px 20px"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <Server size={14} color={C.acc}/>
                <span style={{fontFamily:FS,fontSize:14,fontWeight:600,color:C.tx}}>{h.name}</span>
              </div>
              {h.error ? <Badge color={C.red}>offline</Badge> : <Pulse/>}
            </div>
            {h.error
              ? <p style={{fontFamily:FM,fontSize:11,color:C.red}}>{h.error}</p>
              : <div style={{fontFamily:FM,fontSize:11,color:C.txD}}>{h.running}/{h.containers} conteneurs · {h.cpus} CPUs · {h.memGB} GB RAM</div>
            }
          </Card>
        ))}
        {state.hostsInfo.length === 0 && <p style={{fontFamily:FS,fontSize:13,color:C.txD}}>Aucun hôte Docker configuré</p>}
      </div>

      <h3 style={{fontFamily:FS,fontSize:15,fontWeight:600,color:C.tx,margin:"0 0 14px"}}>Services</h3>
      <Card style={{padding:14}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))",gap:8}}>
          {svcs.map(s => {
            const Ic = ICONS[s.icon] || Globe;
            return (
              <div key={s.id} style={{display:"flex",alignItems:"center",gap:7,padding:"8px 12px",borderRadius:7,border:`1px solid ${C.bdr}`,background:C.bg2}}>
                <Pulse color={s.url ? C.ok : C.warn}/>
                <Ic size={13} color={s.color}/>
                <span style={{fontFamily:FS,fontSize:12,color:C.tx,flex:1}}>{s.label}</span>
                <span style={{fontFamily:FM,fontSize:10,color:C.txD}}>:{s.port}</span>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

/* ── Service iframe ── */
function SvcView({svc, fs, dispatch}) {
  const Ic = ICONS[svc.icon] || Globe;
  const hasUrl = !!svc.url;
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { setLoaded(false); }, [svc.id]);

  return (
    <div style={{flex:1,display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"9px 18px",borderBottom:`1px solid ${C.bdr}`,background:C.side,flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:9}}>
          <Ic size={15} color={svc.color}/>
          <span style={{fontFamily:FS,fontSize:14,fontWeight:600,color:C.tx}}>{svc.label}</span>
          <Badge color={svc.color}>:{svc.port}</Badge>
        </div>
        <div style={{display:"flex",gap:5,alignItems:"center"}}>
          {loaded && <><Pulse/><span style={{fontFamily:FM,fontSize:11,color:C.txD}}>connecté</span></>}
          <IconBtn icon={fs?Minimize2:Maximize2} onClick={() => dispatch({type:"FS"})}/>
          {hasUrl && <a href={`/s/${svc.id}/`} target="_blank" rel="noopener noreferrer" style={{display:"flex"}}><IconBtn icon={ExternalLink}/></a>}
        </div>
      </div>
      {!hasUrl ? (
        <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",background:C.bg}}>
          <div style={{textAlign:"center",animation:"nxUp .35s ease",maxWidth:440}}>
            <AlertTriangle size={40} color={C.warn} strokeWidth={1.2} style={{marginBottom:14}}/>
            <div style={{fontFamily:FS,fontSize:18,fontWeight:600,color:C.tx,marginBottom:8}}>{svc.label} non configuré</div>
            <p style={{fontFamily:FS,fontSize:13,color:C.txD,lineHeight:1.6}}>
              Renseignez l'URL dans <strong style={{color:C.tx}}>Paramètres → Services</strong><br/>
              URL Base du service: <code style={{fontFamily:FM,fontSize:11,color:C.acc}}>{svc.basePath || `/s/${svc.id}`}</code>
            </p>
          </div>
        </div>
      ) : (
        <div style={{flex:1,position:"relative"}}>
          {!loaded && (
            <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:C.bg,zIndex:2}}>
              <Loader2 size={28} color={svc.color} style={{animation:"nxSpin 1s linear infinite",marginBottom:12}}/>
              <span style={{fontFamily:FS,fontSize:13,color:C.txD}}>Chargement de {svc.label}...</span>
            </div>
          )}
          <iframe src={`/s/${svc.id}/`} title={svc.label} onLoad={() => setLoaded(true)}
            style={{width:"100%",height:"100%",border:"none",background:C.bg}} referrerPolicy="no-referrer"/>
        </div>
      )}
    </div>
  );
}

/* ── Docker ── */
function DockerView({state, dispatch}) {
  const [filter, setFilter] = useState("all");
  const [busy, setBusy] = useState(false);
  const toast = useToast(dispatch);

  const filtered = useMemo(() => filter === "all" ? state.containers : state.containers.filter(c => c.host === filter), [state.containers, filter]);
  const run = useMemo(() => filtered.filter(c => c.state === "running").length, [filtered]);

  const refresh = useCallback(async () => {
    setBusy(true);
    try { dispatch({type:"SET", p:{containers: await api.getContainers()}}); }
    catch (e) { toast(e.message, "err"); }
    finally { setBusy(false); }
  }, [dispatch, toast]);

  const act = useCallback(async (hId, cId, action) => {
    try {
      toast(`${action}...`, "info");
      await api.containerAction(hId, cId, action);
      toast(`${action} OK`, "ok");
      setTimeout(refresh, 1500);
    } catch (e) { toast(e.message, "err"); }
  }, [toast, refresh]);

  return (
    <div style={{flex:1,overflow:"auto",padding:28}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:18,flexWrap:"wrap",gap:10}}>
        <div>
          <h2 style={{fontFamily:FS,fontSize:22,fontWeight:700,color:C.tx,margin:0}}>Docker</h2>
          <p style={{fontFamily:FS,fontSize:13,color:C.txD,margin:"2px 0 0"}}>{run}/{filtered.length} en cours</p>
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <TabBar tabs={[{id:"all",label:"Tous"}, ...state.hosts.map(h => ({id:h.id, label:h.name}))]} active={filter} onChange={setFilter}/>
          <Btn icon={busy?Loader2:RefreshCw} small onClick={refresh} disabled={busy}>Refresh</Btn>
        </div>
      </div>
      {filtered.length === 0 ? (
        <Card style={{padding:40,textAlign:"center"}}><p style={{fontFamily:FS,fontSize:14,color:C.txD}}>Aucun conteneur.</p></Card>
      ) : (
        <Card>
          <div style={{display:"grid",gridTemplateColumns:"26px 1.2fr 2fr .7fr .7fr .5fr 130px",padding:"9px 14px",gap:8,borderBottom:`1px solid ${C.bdr}`,background:C.side}}>
            {["","NOM","IMAGE","STATE","STATUS","HOST","ACTIONS"].map((h,i) => (
              <span key={i} style={{fontFamily:FM,fontSize:9,color:C.txD,textTransform:"uppercase",letterSpacing:".1em",textAlign:i===6?"right":"left"}}>{h}</span>
            ))}
          </div>
          {filtered.map(c => {
            const up = c.state === "running";
            const hn = state.hosts.find(h => h.id === c.host);
            return (
              <div key={c.id+c.host}
                style={{display:"grid",gridTemplateColumns:"26px 1.2fr 2fr .7fr .7fr .5fr 130px",alignItems:"center",padding:"10px 14px",gap:8,borderBottom:`1px solid ${C.bdr}08`,transition:"background .1s"}}
                onMouseEnter={e => {e.currentTarget.style.background = C.cardHi}}
                onMouseLeave={e => {e.currentTarget.style.background = "transparent"}}>
                <Pulse color={up?C.ok:C.red}/>
                <span style={{fontFamily:FM,fontSize:12,color:C.tx,fontWeight:600}}>{c.name}</span>
                <span style={{fontFamily:FM,fontSize:10,color:C.txD,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.image}</span>
                <Badge color={up?C.ok:C.red}>{c.state}</Badge>
                <span style={{fontFamily:FM,fontSize:10,color:C.txS,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.status}</span>
                <Badge color={C.blue}>{hn?.name?.split(" ")[0] || c.host}</Badge>
                <div style={{display:"flex",gap:3,justifyContent:"flex-end"}}>
                  {up ? (
                    <>
                      <IconBtn icon={Square} color={C.red} title="Stop" onClick={() => act(c.host,c.id,"stop")} sz={25}/>
                      <IconBtn icon={RotateCcw} color={C.warn} title="Restart" onClick={() => act(c.host,c.id,"restart")} sz={25}/>
                    </>
                  ) : (
                    <IconBtn icon={Play} color={C.ok} title="Start" onClick={() => act(c.host,c.id,"start")} sz={25}/>
                  )}
                  <IconBtn icon={ArrowUpFromLine} color={C.cyan} title="Pull & Recreate" onClick={() => act(c.host,c.id,"pull")} sz={25}/>
                  <IconBtn icon={Terminal} color={C.txD} title="Logs" onClick={() => act(c.host,c.id,"logs")} sz={25}/>
                </div>
              </div>
            );
          })}
        </Card>
      )}
    </div>
  );
}

/* ── Settings ── */
function SettingsView({state, dispatch, refreshData}) {
  const [tab, setTab] = useState("services");
  const [saving, setSaving] = useState(false);
  const toast = useToast(dispatch);

  // Local drafts — only synced from server when NOT dirty (user hasn't edited)
  const [dSvcs, setDSvcs] = useState(state.services);
  const [dHosts, setDHosts] = useState(state.hosts);
  const dirtyRef = useRef(false);

  // Sync from server only if user hasn't made local edits
  useEffect(() => { if (!dirtyRef.current) setDSvcs(state.services); }, [state.services]);
  useEffect(() => { if (!dirtyRef.current) setDHosts(state.hosts); }, [state.hosts]);

  const updSvc = (id, k, v) => { dirtyRef.current = true; setDSvcs(p => p.map(s => s.id === id ? {...s, [k]: v} : s)); };
  const updHost = (id, k, v) => { dirtyRef.current = true; setDHosts(p => p.map(h => h.id === id ? {...h, [k]: v} : h)); };

  const saveAllSvcs = useCallback(async () => {
    setSaving(true);
    try {
      for (const s of dSvcs) {
        await api.updateService(s.id, {
          url: s.url, port: s.port, basePath: s.basePath, rewriteTo: s.rewriteTo,
          authType: s.authType, apiKey: s.apiKey, username: s.username, password: s.password, enabled: s.enabled,
        });
      }
      dirtyRef.current = false;
      toast("Services sauvegardés", "ok");
      refreshData();
    } catch (e) { toast(e.message, "err"); }
    finally { setSaving(false); }
  }, [dSvcs, toast, refreshData]);

  const saveAllHosts = useCallback(async () => {
    setSaving(true);
    try {
      for (const h of dHosts) {
        await api.updateDockerHost(h.id, {name: h.name, ip: h.ip, port: h.port, composePath: h.composePath});
      }
      dirtyRef.current = false;
      toast("Hôtes sauvegardés", "ok");
      refreshData();
    } catch (e) { toast(e.message, "err"); }
    finally { setSaving(false); }
  }, [dHosts, toast, refreshData]);

  const delSvc = useCallback(async (id) => {
    try { await api.deleteService(id); dirtyRef.current = false; toast("Supprimé", "warn"); refreshData(); }
    catch (e) { toast(e.message, "err"); }
  }, [toast, refreshData]);

  const delHost = useCallback(async (id) => {
    try { await api.deleteDockerHost(id); dirtyRef.current = false; toast("Supprimé", "warn"); refreshData(); }
    catch (e) { toast(e.message, "err"); }
  }, [toast, refreshData]);

  const savePerms = useCallback(async () => {
    const perms = {};
    state.users.forEach(u => { if (!u.isAdmin) perms[u.id] = u.perms || {}; });
    try { await api.savePermissions(perms); toast("Permissions sauvegardées", "ok"); }
    catch (e) { toast(e.message, "err"); }
  }, [state.users, toast]);

  const enabledSvcs = useMemo(() => state.services.filter(s => s.enabled), [state.services]);

  return (
    <div style={{flex:1,overflow:"auto",padding:28}}>
      <h2 style={{fontFamily:FS,fontSize:22,fontWeight:700,color:C.tx,margin:"0 0 2px"}}>Paramètres</h2>
      <p style={{fontFamily:FS,fontSize:13,color:C.txD,margin:"0 0 22px"}}>Services, hôtes Docker et permissions</p>
      <div style={{marginBottom:22}}>
        <TabBar tabs={[{id:"services",label:"Services"},{id:"hosts",label:"Hôtes Docker"},{id:"users",label:"Utilisateurs & Accès"}]} active={tab} onChange={setTab}/>
      </div>

      {/* ── Services ── */}
      {tab === "services" && (
        <div style={{display:"grid",gap:12}}>
          {dSvcs.map(s => {
            const Ic = ICONS[s.icon] || Globe;
            return (
              <Card key={s.id} style={{padding:20}}>
                <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
                  <div style={{display:"flex",alignItems:"center",gap:9}}>
                    <Ic size={16} color={s.color}/>
                    <span style={{fontFamily:FS,fontSize:14,fontWeight:600,color:C.tx}}>{s.label}</span>
                    {s.isSSO && <Badge color={C.purple}>SSO</Badge>}
                  </div>
                  <div style={{display:"flex",gap:6,alignItems:"center"}}>
                    <Toggle on={s.enabled} onChange={() => updSvc(s.id, "enabled", !s.enabled)}/>
                    {s.removable && <IconBtn icon={Trash2} color={C.red} title="Supprimer" onClick={() => delSvc(s.id)}/>}
                  </div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr",gap:10,marginBottom:10}}>
                  <Field label="URL interne" value={s.url} mono placeholder={`http://10.0.0.2:${s.port}`} onChange={v => updSvc(s.id, "url", v)}/>
                  <Field label="Port" value={String(s.port || "")} mono onChange={v => updSvc(s.id, "port", parseInt(v) || 0)}/>
                  <Field label="URL Base (service)" value={s.basePath} mono placeholder={`/s/${s.id}`} onChange={v => updSvc(s.id, "basePath", v)}/>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
                  <Sel label="Type d'auth" value={s.authType || "apikey"} onChange={v => updSvc(s.id, "authType", v)}
                    options={[{v:"apikey",l:"API Key"},{v:"basic",l:"User + Password"},{v:"none",l:"Aucune"}]}/>
                  {(s.authType === "apikey" || !s.authType) && (
                    <><Field label="API Key" value={s.apiKey} type="password" mono placeholder="Clé API" onChange={v => updSvc(s.id, "apiKey", v)}/><div/></>
                  )}
                  {s.authType === "basic" && (
                    <><Field label="Utilisateur" value={s.username} mono onChange={v => updSvc(s.id, "username", v)}/>
                    <Field label="Mot de passe" value={s.password} type="password" mono onChange={v => updSvc(s.id, "password", v)}/></>
                  )}
                </div>
                <div style={{marginTop:10,fontFamily:FM,fontSize:10,color:C.txD,lineHeight:1.6}}>
                  Configurer <span style={{color:C.acc}}>URL Base = {s.basePath || `/s/${s.id}`}</span> dans les paramètres de {s.label}
                  {s.authType === "apikey" && <> + <span style={{color:C.amber}}>Authentication = External</span></>}
                </div>
              </Card>
            );
          })}
          <div style={{display:"flex",gap:10}}>
            <Btn icon={Plus} onClick={() => dispatch({type:"MODAL", p:"addSvc"})}>Ajouter un service</Btn>
            <Btn variant="accent" icon={Check} onClick={saveAllSvcs} disabled={saving}>{saving ? "Sauvegarde..." : "Sauvegarder tout"}</Btn>
          </div>
        </div>
      )}

      {/* ── Docker Hosts ── */}
      {tab === "hosts" && (
        <div style={{display:"grid",gap:12}}>
          {dHosts.map(h => (
            <Card key={h.id} style={{padding:20}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16}}>
                <div style={{display:"flex",alignItems:"center",gap:9}}>
                  <Server size={16} color={C.blue}/>
                  <span style={{fontFamily:FS,fontSize:14,fontWeight:600,color:C.tx}}>{h.name}</span>
                </div>
                <IconBtn icon={Trash2} color={C.red} title="Supprimer" onClick={() => delHost(h.id)}/>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
                <Field label="Nom" value={h.name} onChange={v => updHost(h.id, "name", v)}/>
                <Field label="IP" value={h.ip} mono onChange={v => updHost(h.id, "ip", v)}/>
                <Field label="Port API Docker" value={String(h.port || "")} mono onChange={v => updHost(h.id, "port", parseInt(v) || 0)}/>
              </div>
              <div style={{marginTop:10}}>
                <Field label="Chemin docker-compose" value={h.composePath} mono placeholder="/opt/docker" onChange={v => updHost(h.id, "composePath", v)}/>
              </div>
            </Card>
          ))}
          <div style={{display:"flex",gap:10}}>
            <Btn icon={Plus} onClick={async () => {
              try {
                await api.addDockerHost({id:"h"+Date.now(), name:"Nouveau serveur", ip:"0.0.0.0", port:2375, method:"tcp", composePath:"", os:"Linux"});
                dirtyRef.current = false;
                refreshData();
              } catch (e) { toast(e.message, "err"); }
            }}>Ajouter un hôte</Btn>
            <Btn variant="accent" icon={Check} onClick={saveAllHosts} disabled={saving}>{saving ? "Sauvegarde..." : "Sauvegarder tout"}</Btn>
          </div>
        </div>
      )}

      {/* ── Users ── */}
      {tab === "users" && (
        <div>
          {state.users.length === 0 ? (
            <Card style={{padding:30,textAlign:"center"}}>
              <p style={{fontFamily:FS,fontSize:13,color:C.txD}}>Impossible de charger les utilisateurs Jellyfin.</p>
            </Card>
          ) : (
            <>
              <Card>
                <div style={{overflowX:"auto"}}>
                  <div style={{display:"grid",gridTemplateColumns:`200px repeat(${enabledSvcs.length+2},minmax(60px,1fr))`,padding:"11px 18px",borderBottom:`1px solid ${C.bdr}`,background:C.side,minWidth:enabledSvcs.length*70+350}}>
                    <span style={{fontFamily:FS,fontSize:11,color:C.txD,fontWeight:600}}>UTILISATEUR</span>
                    {enabledSvcs.map(s => {
                      const I = ICONS[s.icon] || Globe;
                      return <span key={s.id} style={{fontFamily:FM,fontSize:9,color:C.txD,textAlign:"center",textTransform:"uppercase",display:"flex",flexDirection:"column",alignItems:"center",gap:2}}><I size={11} color={s.color}/>{s.label}</span>;
                    })}
                    <span style={{fontFamily:FM,fontSize:9,color:C.txD,textAlign:"center",textTransform:"uppercase"}}>Docker</span>
                    <span style={{fontFamily:FM,fontSize:9,color:C.txD,textAlign:"center",textTransform:"uppercase"}}>Config</span>
                  </div>
                  {state.users.map(u => (
                    <div key={u.id} style={{display:"grid",gridTemplateColumns:`200px repeat(${enabledSvcs.length+2},minmax(60px,1fr))`,padding:"12px 18px",alignItems:"center",borderBottom:`1px solid ${C.bdr}08`,minWidth:enabledSvcs.length*70+350}}>
                      <div style={{display:"flex",alignItems:"center",gap:9}}>
                        <div style={{width:28,height:28,borderRadius:7,background:`${u.isAdmin?C.acc:C.purple}25`,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FS,fontSize:12,fontWeight:700,color:u.isAdmin?C.acc:C.purple}}>{u.name[0]}</div>
                        <div>
                          <div style={{fontFamily:FS,fontSize:13,fontWeight:600,color:C.tx}}>{u.name}</div>
                          <div style={{fontFamily:FM,fontSize:10,color:C.txD}}>{u.isAdmin?"admin":"user"}</div>
                        </div>
                      </div>
                      {enabledSvcs.map(s => (
                        <div key={s.id} style={{textAlign:"center"}}>
                          <Toggle on={u.isAdmin || !!u.perms?.[s.id]} disabled={u.isAdmin}
                            onChange={() => dispatch({type:"SET", p:{users: state.users.map(x => x.id === u.id ? {...x, perms:{...x.perms, [s.id]:!x.perms?.[s.id]}} : x)}})}/>
                        </div>
                      ))}
                      <div style={{textAlign:"center"}}>
                        <Toggle on={u.isAdmin || !!u.perms?.docker} disabled={u.isAdmin}
                          onChange={() => dispatch({type:"SET", p:{users: state.users.map(x => x.id === u.id ? {...x, perms:{...x.perms, docker:!x.perms?.docker}} : x)}})}/>
                      </div>
                      <div style={{textAlign:"center"}}>
                        <Toggle on={u.isAdmin || !!u.perms?.settings} disabled={u.isAdmin}
                          onChange={() => dispatch({type:"SET", p:{users: state.users.map(x => x.id === u.id ? {...x, perms:{...x.perms, settings:!x.perms?.settings}} : x)}})}/>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
              <div style={{marginTop:12,display:"flex",alignItems:"center",gap:8}}>
                <Shield size={13} color={C.acc}/>
                <span style={{fontFamily:FS,fontSize:12,color:C.txD}}>Utilisateurs Jellyfin. Admins = accès total.</span>
              </div>
              <Btn variant="accent" icon={Check} onClick={savePerms} style={{marginTop:14}}>Sauvegarder les permissions</Btn>
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* ── Add Service Modal ── */
function AddSvcModal({open, onClose, dispatch, refreshData}) {
  const [f, setF] = useState({label:"",icon:"Globe",color:"#3b82f6",port:"",url:"",basePath:""});
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const toast = useToast(dispatch);

  const add = useCallback(async () => {
    if (!f.label.trim()) { setErr("Nom requis"); return; }
    if (!f.port || isNaN(Number(f.port))) { setErr("Port invalide"); return; }
    const id = f.label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    if (!id) { setErr("Nom invalide"); return; }
    setBusy(true); setErr("");
    try {
      await api.addService({id, label:f.label.trim(), icon:f.icon, color:f.color, port:Number(f.port), url:f.url.trim(), basePath:f.basePath.trim() || `/s/${id}`, authType:"apikey"});
      toast(`${f.label} ajouté`, "ok");
      setF({label:"",icon:"Globe",color:"#3b82f6",port:"",url:"",basePath:""});
      refreshData(); onClose();
    } catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  }, [f, toast, refreshData, onClose, dispatch]);

  const Ic = ICONS[f.icon] || Globe;

  return (
    <Modal open={open} onClose={onClose} title="Ajouter un service">
      <div style={{display:"grid",gap:14}}>
        <div style={{display:"flex",alignItems:"center",gap:10,padding:"12px 16px",borderRadius:8,background:C.bg2,border:`1px solid ${C.bdr}`}}>
          <Ic size={18} color={f.color}/><span style={{fontFamily:FS,fontSize:15,fontWeight:600,color:C.tx}}>{f.label || "Nouveau service"}</span>
          {f.port && <Badge color={f.color}>:{f.port}</Badge>}
        </div>
        <Field label="Nom" value={f.label} placeholder="Bazarr, Tdarr, Lidarr..." onChange={v => setF(p => ({...p, label:v}))}/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Field label="Port" value={f.port} placeholder="6767" mono onChange={v => setF(p => ({...p, port:v}))}/>
          <Field label="URL interne" value={f.url} placeholder="http://10.0.0.2:6767" mono onChange={v => setF(p => ({...p, url:v}))}/>
        </div>
        <Field label="URL Base" value={f.basePath} placeholder={`/s/${f.label.toLowerCase().replace(/[^a-z0-9]+/g,"-") || "nom"}`} mono onChange={v => setF(p => ({...p, basePath:v}))}/>
        <div>
          <label style={{fontFamily:FS,fontSize:11,color:C.txD,display:"block",marginBottom:6}}>Icône</label>
          <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
            {ICON_NAMES.map(n => {
              const I = ICONS[n]; const sel = f.icon === n;
              return <button key={n} onClick={() => setF(p => ({...p, icon:n}))} style={{width:34,height:34,borderRadius:7,border:`1px solid ${sel?f.color+"60":C.bdr}`,background:sel?`${f.color}15`:"transparent",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}}><I size={15} color={sel?f.color:C.txD}/></button>;
            })}
          </div>
        </div>
        <div>
          <label style={{fontFamily:FS,fontSize:11,color:C.txD,display:"block",marginBottom:6}}>Couleur</label>
          <div style={{display:"flex",gap:6}}>
            {COLORS.map(c => (
              <button key={c} onClick={() => setF(p => ({...p, color:c}))} style={{width:28,height:28,borderRadius:"50%",border:`2px solid ${f.color===c?c:"transparent"}`,background:c+"30",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
                <span style={{width:14,height:14,borderRadius:"50%",background:c}}/>
              </button>
            ))}
          </div>
        </div>
        {err && <p style={{fontFamily:FS,fontSize:12,color:C.red,margin:0}}>{err}</p>}
        <div style={{display:"flex",gap:8,justifyContent:"flex-end"}}>
          <Btn onClick={onClose}>Annuler</Btn>
          <Btn variant="accent" icon={Plus} onClick={add} disabled={busy}>{busy ? "Ajout..." : "Ajouter"}</Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ── Toasts ── */
function Toasts({toasts}) {
  if (!toasts.length) return null;
  const vc = {ok:C.ok, err:C.red, warn:C.warn, info:C.cyan};
  return (
    <div style={{position:"fixed",bottom:20,right:20,display:"flex",flexDirection:"column",gap:8,zIndex:300}}>
      {toasts.map(t => (
        <div key={t.id} style={{background:C.card,border:`1px solid ${C.bdr}`,borderRadius:9,padding:"10px 16px",fontFamily:FS,fontSize:13,color:C.tx,display:"flex",alignItems:"center",gap:8,animation:"nxSlide .25s ease",boxShadow:`0 6px 24px ${C.bg}cc`,borderLeft:`3px solid ${vc[t.v]||C.cyan}`}}>
          <Circle size={7} fill={vc[t.v]||C.cyan} color="transparent"/>{t.msg}
        </div>
      ))}
    </div>
  );
}

/* ── Main App ── */
export default function App() {
  const [state, dispatch] = useReducer(reducer, INIT);
  const toast = useToast(dispatch);

  // Restore session from cookie on mount
  useEffect(() => {
    api.me()
      .then(d => dispatch({type:"LOGIN", p:d.user}))
      .catch(() => dispatch({type:"SET", p:{loading:false}}));
  }, []);

  // Fetch all data when logged in
  const refreshData = useCallback(async () => {
    try {
      const r = await Promise.allSettled([
        api.getServices(), api.getDockerHosts(), api.stats(),
        api.getContainers().catch(() => []),
        api.getHostsInfo().catch(() => []),
        api.getUsers().catch(() => []),
      ]);
      dispatch({type:"SET", p:{
        services: r[0].status === "fulfilled" ? r[0].value : [],
        hosts: r[1].status === "fulfilled" ? r[1].value : [],
        stats: r[2].status === "fulfilled" ? r[2].value : INIT.stats,
        containers: r[3].status === "fulfilled" ? r[3].value : [],
        hostsInfo: r[4].status === "fulfilled" ? r[4].value : [],
        users: r[5].status === "fulfilled" ? r[5].value : [],
      }});
    } catch (e) { console.error("Refresh:", e); }
  }, []);

  useEffect(() => { if (state.user) refreshData(); }, [state.user, refreshData]);
  // Auto-refresh every 30s (won't overwrite dirty settings thanks to dirtyRef)
  useEffect(() => {
    if (!state.user) return;
    const i = setInterval(refreshData, 30000);
    return () => clearInterval(i);
  }, [state.user, refreshData]);

  // Dynamic nav
  const nav = useMemo(() => {
    const items = [{id:"home", label:"Dashboard", icon:"Home", color:C.acc}];
    state.services.filter(s => s.enabled).forEach(s => items.push(s));
    items.push({id:"docker", label:"Docker", icon:"Container", color:"#38bdf8"});
    items.push({id:"settings", label:"Paramètres", icon:"Settings", color:C.txS});
    return items;
  }, [state.services]);

  const activeSvc = useMemo(() => state.services.find(s => s.id === state.page && s.enabled), [state.services, state.page]);

  // Loading
  if (state.loading) return (
    <div style={{width:"100%",height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:C.bg}}>
      <Loader2 size={32} color={C.acc} style={{animation:"nxSpin 1s linear infinite"}}/>
    </div>
  );

  // Login
  if (!state.user) return <LoginScreen dispatch={dispatch}/>;

  // Main
  return (
    <div style={{width:"100%",height:"100vh",display:"flex",background:C.bg,overflow:"hidden"}}>
      {/* Sidebar */}
      {!state.fs && (
        <div style={{width:state.sidebar?205:54,minWidth:state.sidebar?205:54,background:C.side,borderRight:`1px solid ${C.bdr}`,display:"flex",flexDirection:"column",transition:"all .25s ease",zIndex:10}}>
          {/* Logo */}
          <div style={{padding:state.sidebar?"14px 12px":"14px 10px",borderBottom:`1px solid ${C.bdr}`,display:"flex",alignItems:"center",justifyContent:state.sidebar?"space-between":"center"}}>
            {state.sidebar && (
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:24,height:24,borderRadius:6,background:`linear-gradient(135deg,${C.acc},${C.cyan})`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <Layers size={13} color={C.bg} strokeWidth={2.5}/>
                </div>
                <span style={{fontFamily:FM,fontSize:14,fontWeight:700,color:C.tx}}>Nexus</span>
              </div>
            )}
            <button onClick={() => dispatch({type:"SIDEBAR"})} style={{background:"none",border:"none",cursor:"pointer",padding:2,display:"flex"}}>
              {state.sidebar ? <X size={14} color={C.txD}/> : <Menu size={16} color={C.txD}/>}
            </button>
          </div>

          {/* Nav */}
          <nav style={{flex:1,padding:"8px 5px",display:"flex",flexDirection:"column",gap:1,overflow:"auto"}}>
            {nav.map(n => {
              const isAct = state.page === n.id;
              const Ic = ICONS[n.icon] || Globe;
              return (
                <button key={n.id} onClick={() => dispatch({type:"NAV", p:n.id})}
                  style={{display:"flex",alignItems:"center",gap:8,padding:state.sidebar?"8px 10px":"8px 0",justifyContent:state.sidebar?"flex-start":"center",borderRadius:6,border:"none",cursor:"pointer",background:isAct?`${n.color}10`:"transparent",position:"relative",transition:"background .12s"}}
                  onMouseEnter={e => { if (!isAct) e.currentTarget.style.background = C.cardHi; }}
                  onMouseLeave={e => { e.currentTarget.style.background = isAct ? `${n.color}10` : "transparent"; }}>
                  {isAct && <div style={{position:"absolute",left:-5,top:"50%",transform:"translateY(-50%)",width:3,height:16,borderRadius:2,background:n.color}}/>}
                  <Ic size={16} color={isAct?n.color:C.txD} strokeWidth={isAct?2:1.4}/>
                  {state.sidebar && <span style={{fontFamily:FS,fontSize:12,fontWeight:isAct?600:400,color:isAct?C.tx:C.txS,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{n.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* User */}
          <div style={{padding:state.sidebar?"10px 12px":"10px 6px",borderTop:`1px solid ${C.bdr}`,display:"flex",alignItems:"center",gap:8,justifyContent:state.sidebar?"flex-start":"center"}}>
            <div style={{width:26,height:26,borderRadius:6,background:`${C.acc}30`,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FS,fontSize:11,fontWeight:700,color:C.acc,flexShrink:0}}>
              {state.user.username?.[0] || "?"}
            </div>
            {state.sidebar && (
              <>
                <div style={{flex:1,overflow:"hidden"}}>
                  <div style={{fontFamily:FS,fontSize:12,fontWeight:600,color:C.tx,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{state.user.username}</div>
                  <div style={{fontFamily:FM,fontSize:9,color:C.txD}}>{state.user.isAdmin?"admin":"user"}</div>
                </div>
                <button onClick={async () => { await api.logout().catch(() => {}); dispatch({type:"LOGOUT"}); }}
                  title="Déconnexion" style={{background:"none",border:"none",cursor:"pointer",padding:3,display:"flex"}}>
                  <LogOut size={13} color={C.txD}/>
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Content */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        {state.page === "home" && <DashHome state={state}/>}
        {state.page === "docker" && <DockerView state={state} dispatch={dispatch}/>}
        {state.page === "settings" && <SettingsView state={state} dispatch={dispatch} refreshData={refreshData}/>}
        {activeSvc && <SvcView svc={activeSvc} fs={state.fs} dispatch={dispatch}/>}
      </div>

      <AddSvcModal open={state.modal === "addSvc"} onClose={() => dispatch({type:"MODAL", p:null})} dispatch={dispatch} refreshData={refreshData}/>
      <Toasts toasts={state.toasts}/>
    </div>
  );
}
