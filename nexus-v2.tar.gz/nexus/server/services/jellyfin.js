import logger from "../logger.js";

const jfUrl = () => process.env.JELLYFIN_URL || "http://localhost:8096";
const jfKey = () => process.env.JELLYFIN_API_KEY || "";

async function jf(path, opts = {}) {
  const res = await fetch(`${jfUrl()}${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...(jfKey() && { "X-Emby-Token": jfKey() }),
      ...opts.headers,
    },
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`Jellyfin ${res.status}: ${t.slice(0, 200)}`);
  }
  const ct = res.headers.get("content-type") || "";
  return ct.includes("json") ? res.json() : res.text();
}

export async function authenticateUser(username, password) {
  const data = await jf("/Users/AuthenticateByName", {
    method: "POST",
    body: JSON.stringify({ Username: username, Pw: password }),
    headers: {
      Authorization: 'MediaBrowser Client="Nexus", Device="Server", DeviceId="nexus-server", Version="2.0.0"',
    },
  });
  return {
    userId: data.User.Id,
    username: data.User.Name,
    isAdmin: data.User.Policy?.IsAdministrator === true,
  };
}

export async function getUsers() {
  const users = await jf("/Users");
  return users.map(u => ({
    id: u.Id,
    name: u.Name,
    isAdmin: u.Policy?.IsAdministrator === true,
    isDisabled: u.Policy?.IsDisabled === true,
  }));
}

export async function getMediaStats() {
  try {
    const c = await jf("/Items/Counts");
    return { movies: c.MovieCount || 0, series: c.SeriesCount || 0, episodes: c.EpisodeCount || 0 };
  } catch (e) {
    logger.warn("Media stats: " + e.message);
    return { movies: 0, series: 0, episodes: 0 };
  }
}

export async function getActiveSessions() {
  try {
    const sessions = await jf("/Sessions");
    return sessions.filter(s => s.NowPlayingItem).map(s => ({
      user: s.UserName, client: s.Client, device: s.DeviceName,
      item: s.NowPlayingItem?.Name, type: s.NowPlayingItem?.Type,
    }));
  } catch (e) {
    logger.warn("Sessions: " + e.message);
    return [];
  }
}
