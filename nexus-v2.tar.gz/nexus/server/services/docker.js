import Dockerode from "dockerode";
import logger from "../logger.js";
import config from "../config.js";

const pool = new Map();

function getClient(host) {
  if (pool.has(host.id)) return pool.get(host.id);
  const opts = host.method === "socket"
    ? { socketPath: host.ip || "/var/run/docker.sock" }
    : { host: host.ip, port: host.port || 2375, protocol: host.method === "tls" ? "https" : "http" };
  const client = new Dockerode(opts);
  pool.set(host.id, client);
  return client;
}

function resolveHost(hostId) {
  const h = config.getDockerHosts().find(x => x.id === hostId);
  if (!h) throw new Error("Hôte introuvable: " + hostId);
  return h;
}

export async function listContainers(hostId) {
  const host = resolveHost(hostId);
  const docker = getClient(host);
  const raw = await docker.listContainers({ all: true });
  return raw.map(c => ({
    id: c.Id.slice(0, 12),
    name: (c.Names[0] || "").replace(/^\//, ""),
    image: c.Image, state: c.State, status: c.Status, host: hostId,
    ports: (c.Ports || []).map(p => p.PublicPort ? `${p.PublicPort}:${p.PrivatePort}` : String(p.PrivatePort)).join(", "),
  }));
}

export async function listAllContainers() {
  const results = [];
  for (const host of config.getDockerHosts()) {
    try { results.push(...await listContainers(host.id)); }
    catch (err) { logger.warn(`Docker ${host.name}: ${err.message}`); }
  }
  return results;
}

export async function containerAction(hostId, containerId, action) {
  const host = resolveHost(hostId);
  const docker = getClient(host);
  const container = docker.getContainer(containerId);

  switch (action) {
    case "start": await container.start(); return { ok: true, message: "Démarré" };
    case "stop": await container.stop({ t: 10 }); return { ok: true, message: "Arrêté" };
    case "restart": await container.restart({ t: 10 }); return { ok: true, message: "Redémarré" };
    case "logs": {
      const buf = await container.logs({ stdout: true, stderr: true, tail: 300, timestamps: true });
      return { ok: true, logs: buf.toString("utf-8") };
    }
    case "pull": {
      const info = await container.inspect();
      const image = info.Config.Image;
      logger.info(`Pull & recreate: ${image} on ${host.name}`);
      await new Promise((resolve, reject) => {
        docker.pull(image, (err, stream) => {
          if (err) return reject(err);
          docker.modem.followProgress(stream, err => err ? reject(err) : resolve());
        });
      });
      const wasRunning = info.State.Running;
      if (wasRunning) await container.stop({ t: 10 });
      const name = info.Name.replace(/^\//, "");
      await container.remove();
      const nc = await docker.createContainer({
        ...info.Config, name,
        HostConfig: info.HostConfig,
        NetworkingConfig: { EndpointsConfig: info.NetworkSettings?.Networks || {} },
      });
      if (wasRunning) await nc.start();
      return { ok: true, message: `Pull & recreate OK: ${image}` };
    }
    default: throw new Error("Action inconnue: " + action);
  }
}

export async function getAllHostInfo() {
  const results = [];
  for (const host of config.getDockerHosts()) {
    try {
      const docker = getClient(host);
      const info = await docker.info();
      results.push({
        id: host.id, name: host.name, os: info.OperatingSystem || host.os,
        containers: info.Containers, running: info.ContainersRunning,
        cpus: info.NCPU, memGB: Math.round((info.MemTotal || 0) / 1073741824 * 10) / 10,
      });
    } catch (err) { results.push({ id: host.id, name: host.name, error: err.message }); }
  }
  return results;
}
