import express from "express";
import helmet from "helmet";
import cors from "cors";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

import logger from "./logger.js";
import authRoutes from "./routes/auth.js";
import dockerRoutes from "./routes/docker.js";
import settingsRoutes from "./routes/settings.js";
import { createServiceProxy } from "./routes/proxy.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = parseInt(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === "production";

if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  crossOriginOpenerPolicy: false,
  crossOriginResourcePolicy: false,
}));

app.use(cors({ origin: isProd ? false : ["http://localhost:5173"], credentials: true }));

app.use("/api/", rateLimit({ windowMs: 15 * 60 * 1000, max: parseInt(process.env.RATE_LIMIT_MAX) || 300, standardHeaders: true, legacyHeaders: false }));
app.use("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, max: 15 }));

app.use(cookieParser());
app.use((req, res, next) => {
  if (req.path.startsWith("/s/")) return next();
  compression()(req, res, next);
});
app.use(express.json({ limit: "1mb" }));
app.use(morgan("short", { stream: { write: msg => logger.http(msg.trim()) } }));

// Service proxy FIRST (before static files)
app.use(createServiceProxy());

// API
app.use("/api/auth", authRoutes);
app.use("/api/docker", dockerRoutes);
app.use("/api/settings", settingsRoutes);
app.get("/api/health", (req, res) => res.json({ status: "ok", uptime: process.uptime() }));

// Static frontend
const clientDist = join(__dirname, "..", "client", "dist");
if (isProd && existsSync(clientDist)) {
  app.use(express.static(clientDist, { maxAge: "1d" }));
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/") || req.path.startsWith("/s/")) return res.status(404).json({ error: "Not found" });
    res.sendFile(join(clientDist, "index.html"));
  });
}

app.use((err, req, res, _next) => {
  logger.error(err);
  res.status(err.status || 500).json({ error: isProd ? "Erreur interne" : err.message });
});

app.listen(PORT, () => {
  logger.info(`Nexus v2 on port ${PORT} (${isProd ? "production" : "dev"})`);
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.includes("CHANGE_ME")) logger.warn("JWT_SECRET non defini !");
  if (!process.env.JELLYFIN_URL) logger.warn("JELLYFIN_URL non defini !");
});
