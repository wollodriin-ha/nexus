import { createProxyMiddleware } from "http-proxy-middleware";
import { verifyToken, hasServiceAccess } from "../middleware/auth.js";
import config from "../config.js";
import logger from "../logger.js";

const proxyCache = new Map();

function buildProxy(svc) {
  const key = `${svc.id}:${svc.url}:${svc.authType}:${svc.basePath}:${svc.rewriteTo || ""}`;
  if (proxyCache.has(key)) return proxyCache.get(key);

  const targetUrl = new URL(svc.url);
  const needsRewrite = svc.rewriteTo !== undefined && svc.rewriteTo !== null;

  const proxy = createProxyMiddleware({
    target: svc.url,
    changeOrigin: true,
    ws: true,

    // Automatically rewrite Location headers on redirects (301/302/307/308)
    // This replaces the internal IP:port with the requesting host
    autoRewrite: true,
    hostRewrite: true,
    protocolRewrite: null,  // Will match the incoming protocol (http or https)

    // Path rewriting for services that don't support UrlBase (like Transmission)
    pathRewrite: needsRewrite ? { [`^/s/${svc.id}`]: svc.rewriteTo } : undefined,

    on: {
      proxyReq: (proxyReq, req) => {
        // ── Inject auth ──
        if (svc.authType === "apikey" && svc.apiKey) {
          proxyReq.setHeader("X-Api-Key", svc.apiKey);
          // Also inject as query param — needed for *arr web UI to bypass login page
          const separator = proxyReq.path.includes("?") ? "&" : "?";
          if (!proxyReq.path.includes("apikey=")) {
            proxyReq.path += `${separator}apikey=${svc.apiKey}`;
          }
        } else if (svc.authType === "basic" && svc.username) {
          const encoded = Buffer.from(`${svc.username}:${svc.password || ""}`).toString("base64");
          proxyReq.setHeader("Authorization", `Basic ${encoded}`);
        }

        // Don't leak Nexus cookies to services
        proxyReq.removeHeader("cookie");
      },

      proxyRes: (proxyRes, req, res) => {
        // ── Remove iframe-blocking headers ──
        delete proxyRes.headers["x-frame-options"];
        delete proxyRes.headers["content-security-policy"];
        delete proxyRes.headers["content-security-policy-report-only"];

        // ── Remove service cookies (they overwrite our JWT cookie) ──
        delete proxyRes.headers["set-cookie"];

        // ── Rewrite Location headers on redirects ──
        // autoRewrite handles most cases, but we also manually fix
        // any Location that still contains the internal IP
        if (proxyRes.headers.location) {
          const loc = proxyRes.headers.location;
          const internalOrigin = svc.url.replace(/\/$/, "");

          if (loc.startsWith(internalOrigin) || loc.includes(targetUrl.host)) {
            // Replace internal origin with relative path
            // e.g. http://10.0.0.2:8989/s/sonarr/login → /s/sonarr/login
            const protocol = req.headers["x-forwarded-proto"] || (req.secure ? "https" : "http");
            const host = req.headers["x-forwarded-host"] || req.headers.host;
            const newLoc = loc
              .replace(internalOrigin, `${protocol}://${host}`)
              .replace(`http://${targetUrl.host}`, `${protocol}://${host}`)
              .replace(`https://${targetUrl.host}`, `${protocol}://${host}`);
            proxyRes.headers.location = newLoc;
            logger.debug(`Redirect rewrite: ${loc} → ${newLoc}`);
          }
        }

        // ── Rewrite any Content-Type text/html that references internal IPs ──
        // This handles cases where services embed absolute URLs in their HTML/JS
        // We intercept the response body for HTML responses
      },

      error: (err, req, res) => {
        logger.error(`Proxy ${svc.id}: ${err.message}`);
        if (res && !res.headersSent) {
          res.status(502).send(
            `<!DOCTYPE html><html><body style="background:#0a0e17;color:#dfe6f2;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">` +
            `<div style="text-align:center"><h2>${svc.label} indisponible</h2><p style="color:#8896b3">${err.message}</p></div></body></html>`
          );
        }
      },
    },
    timeout: 30_000,
    proxyTimeout: 30_000,

    // Handle self-signed certs if services use HTTPS internally
    secure: false,
  });

  proxyCache.set(key, proxy);
  logger.info(`Proxy: /s/${svc.id} → ${svc.url} (auth=${svc.authType}, rewrite=${needsRewrite ? svc.rewriteTo : "none"})`);
  return proxy;
}

export function createServiceProxy() {
  return (req, res, next) => {
    const match = req.path.match(/^\/s\/([a-z0-9-]+)(\/.*)?$/);
    if (!match) return next();

    const serviceId = match[1];
    const svc = config.getServiceById(serviceId);

    if (!svc || !svc.enabled) return res.status(404).send("Service introuvable");
    if (!svc.url) return res.status(400).send(`${svc.label}: URL non configurée`);

    // Auth
    const token = req.cookies?.nexus_token;
    if (!token) return res.redirect("/?auth_required=1");

    let user;
    try { user = verifyToken(token); }
    catch { return res.redirect("/?session_expired=1"); }

    if (!hasServiceAccess(user, serviceId)) return res.status(403).send("Accès refusé");

    const proxy = buildProxy(svc);
    proxy(req, res, next);
  };
}

export function clearProxyCache() {
  proxyCache.clear();
}
