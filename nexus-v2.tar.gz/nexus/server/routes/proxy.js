import { createProxyMiddleware } from "http-proxy-middleware";
import { verifyToken, hasServiceAccess } from "../middleware/auth.js";
import config from "../config.js";
import logger from "../logger.js";

/**
 * Server-side subpath proxy.
 *
 * How it works:
 *   1. Each service is configured with a basePath, e.g. /s/sonarr
 *   2. The service itself must be configured with UrlBase = /s/sonarr
 *   3. Browser requests /s/sonarr/calendar
 *   4. Nexus auth-checks the cookie, then forwards to http://10.0.0.2:8989/s/sonarr/calendar
 *   5. Sonarr responds (it recognizes /s/sonarr because of its UrlBase)
 *   6. Nexus strips X-Frame-Options and returns the response
 *
 * No path rewriting needed — the basePath is the same on both sides.
 */

const proxyInstances = new Map();

function buildProxy(svc) {
  const key = `${svc.id}:${svc.url}`;
  if (proxyInstances.has(key)) return proxyInstances.get(key);

  const proxy = createProxyMiddleware({
    target: svc.url,
    changeOrigin: true,
    ws: true,
    // No pathRewrite — the path stays the same (basePath is identical on both sides)
    on: {
      proxyReq: (proxyReq) => {
        // Inject auth headers based on service config
        if (svc.authType === "apikey" && svc.apiKey) {
          proxyReq.setHeader("X-Api-Key", svc.apiKey);
          // Also as query param for initial page loads (some services need it)
          // This is handled by the URL having ?apikey= for *arr apps
        } else if (svc.authType === "basic" && svc.username) {
          const encoded = Buffer.from(`${svc.username}:${svc.password || ""}`).toString("base64");
          proxyReq.setHeader("Authorization", `Basic ${encoded}`);
        }
        // Remove cookie header so service doesn't see Nexus auth cookies
        proxyReq.removeHeader("cookie");
      },
      proxyRes: (proxyRes) => {
        // Remove headers that prevent iframe embedding
        delete proxyRes.headers["x-frame-options"];
        delete proxyRes.headers["content-security-policy"];
        delete proxyRes.headers["content-security-policy-report-only"];
      },
      error: (err, req, res) => {
        logger.error(`Proxy ${svc.id}: ${err.message}`);
        if (res && !res.headersSent) {
          res.status(502).send(`<h3>Service ${svc.label} indisponible</h3><p>${err.message}</p>`);
        }
      },
    },
    timeout: 30_000,
    proxyTimeout: 30_000,
  });

  proxyInstances.set(key, proxy);
  logger.info(`Proxy: ${svc.basePath} → ${svc.url}`);
  return proxy;
}

/**
 * Mount function — called from index.js
 * Creates Express middleware that handles all /s/* requests
 */
export function createServiceProxy() {
  return (req, res, next) => {
    // Extract service ID from path: /s/sonarr/anything → "sonarr"
    const match = req.path.match(/^\/s\/([a-z0-9-]+)(\/.*)?$/);
    if (!match) return next();

    const serviceId = match[1];
    const svc = config.getServiceById(serviceId);

    if (!svc || !svc.enabled) return res.status(404).send("Service introuvable");
    if (!svc.url) return res.status(400).send(`Service ${svc.label}: URL non configurée`);

    // Auth check via cookie
    const token = req.cookies?.nexus_token;
    if (!token) {
      // Redirect to login page instead of JSON error (nicer UX in iframe)
      return res.redirect("/?auth_required=1");
    }

    let user;
    try {
      user = verifyToken(token);
    } catch {
      return res.redirect("/?session_expired=1");
    }

    // Permission check
    if (!hasServiceAccess(user, serviceId)) {
      return res.status(403).send("Accès refusé à ce service");
    }

    // Proxy the request
    const proxy = buildProxy(svc);
    proxy(req, res, next);
  };
}

/** Clear proxy cache (call when config changes) */
export function clearProxyCache() {
  proxyInstances.clear();
}
