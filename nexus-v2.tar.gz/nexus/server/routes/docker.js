import { Router } from "express";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import * as docker from "../services/docker.js";
import logger from "../logger.js";

const router = Router();
router.use(requireAuth, requireAdmin);

router.get("/containers", async (req, res) => {
  try {
    const { host } = req.query;
    const containers = host ? await docker.listContainers(host) : await docker.listAllContainers();
    res.json(containers);
  } catch (err) {
    logger.error("Docker list: " + err.message);
    res.status(500).json({ error: err.message });
  }
});

router.post("/containers/:hostId/:containerId/:action", async (req, res) => {
  const { hostId, containerId, action } = req.params;
  const allowed = ["start", "stop", "restart", "logs", "pull"];
  if (!allowed.includes(action)) return res.status(400).json({ error: "Action invalide" });

  try {
    logger.info(`Docker ${action}: ${containerId} on ${hostId} by ${req.user.username}`);
    const result = await docker.containerAction(hostId, containerId, action);
    res.json(result);
  } catch (err) {
    logger.error(`Docker ${action}: ${err.message}`);
    res.status(500).json({ error: err.message });
  }
});

router.get("/hosts/info", async (req, res) => {
  try { res.json(await docker.getAllHostInfo()); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

export default router;
