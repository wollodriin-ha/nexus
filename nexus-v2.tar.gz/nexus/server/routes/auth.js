import { Router } from "express";
import { authenticateUser } from "../services/jellyfin.js";
import { signToken, requireAuth, cookieOptions } from "../middleware/auth.js";
import logger from "../logger.js";

const router = Router();

router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: "Champs requis" });

  try {
    const jfUser = await authenticateUser(username, password);
    const token = signToken({
      userId: jfUser.userId,
      username: jfUser.username,
      isAdmin: jfUser.isAdmin,
    });

    res.cookie("nexus_token", token, cookieOptions(req));
    logger.info(`Login: ${jfUser.username} (admin=${jfUser.isAdmin})`);
    res.json({ user: { userId: jfUser.userId, username: jfUser.username, isAdmin: jfUser.isAdmin }, token });
  } catch (err) {
    logger.warn(`Login failed for "${username}": ${err.message}`);
    res.status(401).json({ error: "Identifiants invalides" });
  }
});

router.post("/logout", (req, res) => {
  res.clearCookie("nexus_token", { path: "/" });
  res.json({ ok: true });
});

router.get("/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

export default router;
