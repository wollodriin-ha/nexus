import jwt from "jsonwebtoken";
import config from "../config.js";

const SECRET = () => process.env.JWT_SECRET || "INSECURE_DEFAULT_CHANGE_ME";

export function signToken(payload) {
  return jwt.sign(payload, SECRET(), { expiresIn: process.env.JWT_EXPIRY || "7d" });
}

export function verifyToken(token) {
  return jwt.verify(token, SECRET());
}

/** Build cookie options based on request protocol */
export function cookieOptions(req) {
  const isHttps = req.secure || req.headers["x-forwarded-proto"] === "https";
  return {
    httpOnly: true,
    secure: isHttps,
    sameSite: "lax",    // "lax" works for same-origin iframes
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  };
}

/** Extract JWT from cookie or Authorization header */
function extractToken(req) {
  return req.cookies?.nexus_token || req.headers.authorization?.replace("Bearer ", "") || null;
}

/** Express middleware: require valid JWT */
export function requireAuth(req, res, next) {
  const token = extractToken(req);
  if (!token) return res.status(401).json({ error: "Non authentifié" });

  try {
    req.user = verifyToken(token);
    next();
  } catch {
    res.clearCookie("nexus_token", { path: "/" });
    return res.status(401).json({ error: "Session expirée" });
  }
}

/** Express middleware: require admin */
export function requireAdmin(req, res, next) {
  if (!req.user?.isAdmin) return res.status(403).json({ error: "Accès admin requis" });
  next();
}

/** Check if user has permission for a specific service */
export function hasServiceAccess(user, serviceId) {
  if (user?.isAdmin) return true;
  const perms = config.getUserPerms(user?.userId);
  return perms && perms[serviceId] === true;
}
