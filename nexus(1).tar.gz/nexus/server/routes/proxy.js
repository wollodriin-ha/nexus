import { Router } from "express";
import { createProxyMiddleware } from "http-proxy-middleware";
import { requireAuth } from "../middleware/auth.js";
import config from "../config.js";
import logger from "../logger.js";

const router = Router();

// Cache proxy instances per service to avoid recreating on every request
const proxyCache = new Map();

function getOrCreateProxy(svc) {
  if (proxyCache.has(svc.id)) {
    const cached = proxyCache.get(svc.id);
    // Invalidate if URL changed
    if (cached._targetUrl === svc.url) return cached.proxy;
    proxyCache.delete(svc.id);
  }

  const proxy = createProxyMiddleware({
    target: svc.url,
    changeOrigin: true,
    ws: true,
    // Rewrite /api/proxy/sonarr/anything → /anything
    pathRewrite: (path) => {
      const prefix = `/api/proxy/${svc.id}`;
      return path.startsWith(prefix) ? path.slice(prefix.length) || "/" : path;
    },
    on: {
      proxyRes: (proxyRes) => {
        // Remove headers that block iframe embedding
        delete proxyRes.headers["x-frame-options"];
        delete proxyRes.headers["content-security-policy"];
        delete proxyRes.headers["content-security-policy-report-only"];
        // Allow embedding in Nexus
        proxyRes.headers["x-frame-options"] = "SAMEORIGIN";
      },
      error: (err, req, res) => {
        logger.error(`Proxy ${svc.id}: ${err.message}`);
        if (!res.headersSent) {
          res.status(502).json({ error: `Service ${svc.label} indisponible` });
        }
      },
    },
    timeout: 30_000,
    proxyTimeout: 30_000,
    // Don't follow redirects, let the browser handle them within the iframe
    followRedirects: false,
  });

  proxyCache.set(svc.id, { proxy, _targetUrl: svc.url });
  logger.info(`Proxy created: ${svc.id} → ${svc.url}`);
  return proxy;
}

/**
 * Auth gate: check JWT + per-service permission, then proxy.
 * Route: /api/proxy/:serviceId/**
 */
router.use("/:serviceId", requireAuth, (req, res, next) => {
  const serviceId = req.params.serviceId;
  const svc = config.getServiceById(serviceId);

  if (!svc || !svc.enabled) {
    return res.status(404).json({ error: "Service introuvable ou désactivé" });
  }
  if (!svc.url) {
    return res.status(400).json({ error: `URL non configurée pour ${svc.label}. Allez dans Paramètres.` });
  }

  // Permission check (admins pass through)
  if (!req.user.isAdmin) {
    const perms = config.getUserPerms(req.user.userId);
    if (!perms || !perms[serviceId]) {
      return res.status(403).json({ error: "Accès refusé à ce service" });
    }
  }

  const proxy = getOrCreateProxy(svc);
  proxy(req, res, next);
});

// Invalidate cache when config changes
export function clearProxyCache(serviceId) {
  if (serviceId) proxyCache.delete(serviceId);
  else proxyCache.clear();
}

export default router;
