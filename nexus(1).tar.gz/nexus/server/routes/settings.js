import { Router } from "express";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import { getUsers, getMediaStats, getActiveSessions } from "../services/jellyfin.js";
import config from "../config.js";
import logger from "../logger.js";

const router = Router();
router.use(requireAuth);

// ── Dashboard stats ──────────────────────────────────────────
router.get("/stats", async (req, res) => {
  try {
    const [media, sessions] = await Promise.all([getMediaStats(), getActiveSessions()]);
    res.json({ media, streams: sessions.length, sessions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Services CRUD (admin only) ───────────────────────────────
router.get("/services", (req, res) => {
  const svcs = config.getServices();
  // Strip API keys for non-admins
  if (!req.user.isAdmin) {
    return res.json(svcs.map(s => ({ ...s, apiKey: s.apiKey ? "••••••" : "" })));
  }
  res.json(svcs);
});

router.put("/services/:id", requireAdmin, (req, res) => {
  try {
    config.updateService(req.params.id, req.body);
    logger.info(`Service updated: ${req.params.id} by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/services", requireAdmin, (req, res) => {
  try {
    const { id, label, icon, color, port, url } = req.body;
    if (!id || !label || !port) return res.status(400).json({ error: "id, label et port requis" });
    // Sanitize ID
    const cleanId = String(id).toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 32);
    if (!cleanId) return res.status(400).json({ error: "ID invalide" });
    config.addService({ id: cleanId, label, icon: icon || "Globe", color: color || "#3b82f6", port: Number(port), url: url || "", apiKey: "" });
    logger.info(`Service added: ${cleanId} by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete("/services/:id", requireAdmin, (req, res) => {
  try {
    config.removeService(req.params.id);
    logger.info(`Service removed: ${req.params.id} by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ── Docker Hosts CRUD (admin only) ───────────────────────────
router.get("/docker-hosts", requireAdmin, (req, res) => {
  res.json(config.getDockerHosts());
});

router.post("/docker-hosts", requireAdmin, (req, res) => {
  try {
    const { id, name, ip, port, method, composePath, os } = req.body;
    if (!id || !name || !ip) return res.status(400).json({ error: "id, name et ip requis" });
    config.addDockerHost({ id, name, ip, port: Number(port) || 2375, method: method || "tcp", composePath: composePath || "", os: os || "Linux" });
    logger.info(`Docker host added: ${name} by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.put("/docker-hosts/:id", requireAdmin, (req, res) => {
  try {
    config.updateDockerHost(req.params.id, req.body);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete("/docker-hosts/:id", requireAdmin, (req, res) => {
  try {
    config.removeDockerHost(req.params.id);
    logger.info(`Docker host removed: ${req.params.id} by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ── Jellyfin Users + Permissions (admin only) ────────────────
router.get("/users", requireAdmin, async (req, res) => {
  try {
    const jfUsers = await getUsers();
    const perms = config.getPermissions();
    const merged = jfUsers.filter(u => !u.isDisabled).map(u => ({
      ...u,
      perms: perms[u.id] || {},
    }));
    res.json(merged);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put("/permissions", requireAdmin, (req, res) => {
  try {
    const { permissions } = req.body;
    if (!permissions || typeof permissions !== "object") return res.status(400).json({ error: "Format invalide" });
    config.setAllPermissions(permissions);
    logger.info(`Permissions updated by ${req.user.username}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
