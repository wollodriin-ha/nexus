import { Router } from "express";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import * as docker from "../services/docker.js";
import logger from "../logger.js";

const router = Router();
router.use(requireAuth, requireAdmin);

// List containers (all hosts or specific)
router.get("/containers", async (req, res) => {
  try {
    const { host } = req.query;
    const containers = host ? await docker.listContainers(host) : await docker.listAllContainers();
    res.json(containers);
  } catch (err) {
    logger.error("Docker list: " + err.message);
    res.status(500).json({ error: err.message });
  }
});

// Container action
router.post("/containers/:hostId/:containerId/:action", async (req, res) => {
  const { hostId, containerId, action } = req.params;
  const allowed = ["start", "stop", "restart", "logs", "pull"];
  if (!allowed.includes(action)) return res.status(400).json({ error: "Action invalide" });

  try {
    logger.info(`Docker ${action}: ${containerId} on ${hostId} by ${req.user.username}`);
    const result = await docker.containerAction(hostId, containerId, action);
    res.json(result);
  } catch (err) {
    logger.error(`Docker ${action} failed: ${err.message}`);
    res.status(500).json({ error: err.message });
  }
});

// Docker-compose up -d (via exec on host — requires SSH or agent)
router.post("/compose/:hostId", async (req, res) => {
  // In production: execute via SSH or a Docker agent container
  // For now, return info that this needs host-level access
  res.json({ ok: true, message: "docker-compose up -d triggered (requires host agent)" });
});

// Host info
router.get("/hosts/info", async (req, res) => {
  try {
    const info = await docker.getAllHostInfo();
    res.json(info);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
