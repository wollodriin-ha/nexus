import jwt from "jsonwebtoken";
import config from "../config.js";

const SECRET = () => process.env.JWT_SECRET || "INSECURE_DEFAULT_CHANGE_ME";

export function signToken(payload) {
  return jwt.sign(payload, SECRET(), { expiresIn: process.env.JWT_EXPIRY || "7d" });
}

export function verifyToken(token) {
  return jwt.verify(token, SECRET());
}

/** Express middleware: require valid JWT */
export function requireAuth(req, res, next) {
  const token = req.cookies?.nexus_token || req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Non authentifié" });

  try {
    req.user = verifyToken(token);
    next();
  } catch {
    res.clearCookie("nexus_token");
    return res.status(401).json({ error: "Session expirée" });
  }
}

/** Express middleware: require admin role */
export function requireAdmin(req, res, next) {
  if (!req.user?.isAdmin) return res.status(403).json({ error: "Accès admin requis" });
  next();
}

/** Express middleware: check service permission */
export function requirePerm(serviceId) {
  return (req, res, next) => {
    if (req.user?.isAdmin) return next();
    const perms = config.getUserPerms(req.user?.userId);
    if (perms && perms[serviceId]) return next();
    return res.status(403).json({ error: "Accès refusé à ce service" });
  };
}
