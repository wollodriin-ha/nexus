import express from "express";
import helmet from "helmet";
import cors from "cors";
import compression from "compression";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

import logger from "./logger.js";
import authRoutes from "./routes/auth.js";
import dockerRoutes from "./routes/docker.js";
import proxyRoutes from "./routes/proxy.js";
import settingsRoutes from "./routes/settings.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = parseInt(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === "production";

// ── Security ─────────────────────────────────────────────────
if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);

app.use(helmet({
  contentSecurityPolicy: false,  // Disabled — Nexus proxies iframes from internal services
  crossOriginEmbedderPolicy: false,
  crossOriginOpenerPolicy: false,
  crossOriginResourcePolicy: false,
}));

app.use(cors({
  origin: isProd ? false : ["http://localhost:5173"],
  credentials: true,
}));

app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Trop de requêtes, réessayez plus tard" },
}));

// Stricter limit on login
app.use("/api/auth/login", rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  message: { error: "Trop de tentatives de connexion" },
}));

// ── Middleware ────────────────────────────────────────────────
app.use(compression());
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("short", { stream: { write: msg => logger.http(msg.trim()) } }));

// ── API Routes ───────────────────────────────────────────────
app.use("/api/auth", authRoutes);
app.use("/api/docker", dockerRoutes);
app.use("/api/proxy", proxyRoutes);
app.use("/api/settings", settingsRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", uptime: process.uptime(), timestamp: Date.now() });
});

// ── Static frontend (production) ─────────────────────────────
const clientDist = join(__dirname, "..", "client", "dist");
if (isProd && existsSync(clientDist)) {
  app.use(express.static(clientDist, { maxAge: "1d" }));
  // SPA fallback
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Not found" });
    res.sendFile(join(clientDist, "index.html"));
  });
}

// ── Error handler ────────────────────────────────────────────
app.use((err, req, res, _next) => {
  logger.error(err);
  res.status(err.status || 500).json({
    error: isProd ? "Erreur interne" : err.message,
  });
});

// ── Start ────────────────────────────────────────────────────
app.listen(PORT, () => {
  logger.info(`Nexus server running on port ${PORT} (${isProd ? "production" : "development"})`);
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.includes("CHANGE_ME")) {
    logger.warn("⚠ JWT_SECRET is not set! Generate one with: openssl rand -hex 32");
  }
  if (!process.env.JELLYFIN_URL) {
    logger.warn("⚠ JELLYFIN_URL is not set — authentication will not work");
  }
});

export default app;
