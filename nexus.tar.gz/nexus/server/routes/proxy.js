import { Router } from "express";
import { createProxyMiddleware } from "http-proxy-middleware";
import { requireAuth, requirePerm } from "../middleware/auth.js";
import config from "../config.js";
import logger from "../logger.js";

const router = Router();

/**
 * Dynamic proxy: /api/proxy/:serviceId/* → service URL
 * Auth: JWT required + service permission check
 * Headers: removes X-Frame-Options to allow iframe embedding
 */
router.use("/:serviceId", requireAuth, (req, res, next) => {
  const svc = config.getServiceById(req.params.serviceId);
  if (!svc || !svc.enabled) return res.status(404).json({ error: "Service introuvable ou désactivé" });
  if (!svc.url) return res.status(400).json({ error: "URL du service non configurée" });

  // Permission check
  if (!req.user.isAdmin) {
    const perms = config.getUserPerms(req.user.userId);
    if (!perms || !perms[svc.id]) return res.status(403).json({ error: "Accès refusé" });
  }

  // Create proxy on-the-fly
  const proxy = createProxyMiddleware({
    target: svc.url,
    changeOrigin: true,
    pathRewrite: { [`^/api/proxy/${svc.id}`]: "" },
    on: {
      proxyReq: (proxyReq) => {
        // Forward API key if service has one
        if (svc.apiKey) {
          proxyReq.setHeader("X-Api-Key", svc.apiKey);
        }
      },
      proxyRes: (proxyRes) => {
        // Allow iframe embedding
        delete proxyRes.headers["x-frame-options"];
        delete proxyRes.headers["content-security-policy"];
        proxyRes.headers["x-frame-options"] = "SAMEORIGIN";
      },
      error: (err) => {
        logger.error(`Proxy ${svc.id}: ${err.message}`);
      },
    },
    timeout: 30_000,
  });

  proxy(req, res, next);
});

export default router;
